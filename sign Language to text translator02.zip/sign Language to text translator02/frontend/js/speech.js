/**
 * SignBridge AI - Text-to-Speech Engine
 * Web SpeechSynthesis API wrapper with rate control, voice selection, and interruption prevention.
 */

const SpeechEngine = {
  isSupported() {
    return 'speechSynthesis' in window;
  },

  speak(text, options = {}) {
    if (!this.isSupported()) {
      console.warn("[SpeechEngine] Web SpeechSynthesis not supported by this browser.");
      return;
    }

    if (!text || text.trim() === "") return;

    // Cancel current utterance to avoid audio overlap
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options.rate || 0.95;
    utterance.pitch = options.pitch || 1.0;
    utterance.volume = options.volume || 1.0;

    // Select suitable English voice
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      const preferred = voices.find(v => v.lang.startsWith("en") && (v.name.includes("Google") || v.name.includes("Natural") || v.name.includes("Samantha")));
      if (preferred) {
        utterance.voice = preferred;
      }
    }

    window.speechSynthesis.speak(utterance);
  },

  stop() {
    if (this.isSupported()) {
      window.speechSynthesis.cancel();
    }
  }
};
