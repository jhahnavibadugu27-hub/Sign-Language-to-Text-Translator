/**
 * SignBridge AI - Image Translator Controller
 */

const ImageTranslator = {
  currentFile: null,

  init() {
    this.dropzone = document.getElementById("image-dropzone");
    this.fileInput = document.getElementById("image-file-input");
    this.previewImg = document.getElementById("preview-img");
    this.previewEmpty = document.getElementById("preview-empty");
    this.submitBtn = document.getElementById("btn-translate-image");
    
    // Result elements
    this.resultContainer = document.getElementById("image-results");
    this.signTokenElem = document.getElementById("res-sign-token");
    this.confValueElem = document.getElementById("res-confidence-val");
    this.confBarElem = document.getElementById("res-confidence-bar");
    this.sentenceElem = document.getElementById("res-sentence");
    this.procTimeElem = document.getElementById("res-proc-time");
    this.probContainer = document.getElementById("res-prob-bars");
    this.speakBtn = document.getElementById("btn-speak-image");

    this.bindEvents();
  },

  bindEvents() {
    if (!this.dropzone) return;

    this.dropzone.addEventListener("click", () => this.fileInput.click());

    this.dropzone.addEventListener("dragover", (e) => {
      e.preventDefault();
      this.dropzone.classList.add("dragover");
    });

    this.dropzone.addEventListener("dragleave", () => {
      this.dropzone.classList.remove("dragover");
    });

    this.dropzone.addEventListener("drop", (e) => {
      e.preventDefault();
      this.dropzone.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        this.handleFile(e.dataTransfer.files[0]);
      }
    });

    this.fileInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        this.handleFile(e.target.files[0]);
      }
    });

    this.submitBtn.addEventListener("click", () => this.translate());

    if (this.speakBtn) {
      this.speakBtn.addEventListener("click", () => {
        const text = this.sentenceElem ? this.sentenceElem.textContent : "";
        SpeechEngine.speak(text);
      });
    }
  },

  handleFile(file) {
    if (!file.type.startsWith("image/")) {
      App.showToast("Please upload a valid image file (JPG/PNG).", "error");
      return;
    }

    this.currentFile = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      this.previewImg.src = e.target.result;
      this.previewImg.style.display = "block";
      if (this.previewEmpty) this.previewEmpty.style.display = "none";
      this.submitBtn.disabled = false;
    };
    reader.readAsDataURL(file);
  },

  async translate() {
    if (!this.currentFile) return;

    this.submitBtn.disabled = true;
    this.submitBtn.innerHTML = `<span>Processing...</span>`;

    const formData = new FormData();
    formData.append("file", this.currentFile);
    formData.append("language", App.activeLanguage);

    try {
      const data = await API.post("/api/translation/image", formData);

      // Render results
      this.resultContainer.style.display = "block";
      this.signTokenElem.textContent = data.sign;
      
      const confPct = Math.round(data.confidence * 100);
      this.confValueElem.textContent = `${confPct}%`;
      this.confBarElem.style.width = `${confPct}%`;
      this.sentenceElem.textContent = data.sentence;
      this.procTimeElem.textContent = `${data.processing_time_ms} ms`;

      // Update preview with annotated skeleton image from backend
      if (data.annotated_image) {
        this.previewImg.src = data.annotated_image;
      }

      // Render top 4 probabilities
      if (data.probabilities) {
        const sorted = Object.entries(data.probabilities)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 4);

        this.probContainer.innerHTML = sorted.map(([cls, prob]) => `
          <div class="prob-row">
            <span style="font-weight: 600; width: 80px;">${cls}</span>
            <div class="prob-row-bar">
              <div class="prob-fill" style="width: ${Math.round(prob * 100)}%;"></div>
            </div>
            <span style="font-family: var(--font-mono); font-size: 0.8rem; width: 45px; text-align: right;">
              ${Math.round(prob * 100)}%
            </span>
          </div>
        `).join("");
      }

      // Automatic speech announcement
      SpeechEngine.speak(data.sentence);
      App.showToast(`Recognized: ${data.sign} (${confPct}%)`, "success");

    } catch (err) {
      App.showToast(err.message || "Failed to process image.", "error");
    } finally {
      this.submitBtn.disabled = false;
      this.submitBtn.innerHTML = `<span>Translate Sign Image</span>`;
    }
  }
};

document.addEventListener("DOMContentLoaded", () => ImageTranslator.init());
