/**
 * SignBridge AI - Centralized API Client
 * Handles HTTP requests, JWT injection, and connection fallback.
 */

const API_BASE_URL = window.location.origin.includes("http") && !window.location.origin.includes("null") 
  ? window.location.origin 
  : "http://127.0.0.1:8000";

const API = {
  getToken() {
    return localStorage.getItem("signbridge_token");
  },

  setToken(token) {
    localStorage.setItem("signbridge_token", token);
  },

  clearToken() {
    localStorage.removeItem("signbridge_token");
    localStorage.removeItem("signbridge_user");
  },

  getUser() {
    const userStr = localStorage.getItem("signbridge_user");
    return userStr ? JSON.parse(userStr) : null;
  },

  setUser(user) {
    localStorage.setItem("signbridge_user", JSON.stringify(user));
  },

  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const headers = options.headers || {};

    const token = this.getToken();
    if (token && !headers["Authorization"]) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    if (!(options.body instanceof FormData) && !headers["Content-Type"]) {
      headers["Content-Type"] = "application/json";
    }

    try {
      const response = await fetch(url, { ...options, headers });
      const contentType = response.headers.get("content-type") || "";

      let data;
      if (contentType.includes("application/json")) {
        data = await response.json();
      } else {
        data = await response.text();
      }

      if (!response.ok) {
        const errorMsg = (data && data.detail) || response.statusText || "Request failed";
        throw new Error(errorMsg);
      }

      return data;
    } catch (err) {
      console.error(`[API Error] ${endpoint}:`, err);
      throw err;
    }
  },

  get(endpoint) {
    return this.request(endpoint, { method: "GET" });
  },

  post(endpoint, body) {
    return this.request(endpoint, {
      method: "POST",
      body: body instanceof FormData ? body : JSON.stringify(body)
    });
  },

  delete(endpoint) {
    return this.request(endpoint, { method: "DELETE" });
  }
};
