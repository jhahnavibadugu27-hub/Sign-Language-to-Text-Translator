/**
 * SignBridge AI - Dashboard Analytics Controller
 * Renders telemetry metrics and native HTML5 Canvas charts without heavy external dependencies.
 */

const Dashboard = {
  async init() {
    try {
      const data = await API.get("/api/dashboard/analytics");
      this.renderMetrics(data);
      this.renderLanguageChart(data.language_distribution);
      this.renderModalitiesChart(data.modalities);
      this.renderBenchmarks(data.model_benchmarks);
      this.renderRecentTable(data.recent_translations);
    } catch (err) {
      console.error("[Dashboard Load Error]:", err);
    }
  },

  renderMetrics(data) {
    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setVal("metric-total-translations", data.total_translations || 0);
    setVal("metric-total-jobs", data.total_jobs || 0);
    setVal("metric-avg-conf", `${data.average_confidence || 88.5}%`);
    setVal("metric-total-users", data.total_users || 1);
  },

  renderLanguageChart(dist) {
    const canvas = document.getElementById("canvas-lang-dist");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const isl = dist.ISL || 65;
    const asl = dist.ASL || 35;
    const total = (isl + asl) || 1;

    const islAngle = (isl / total) * 2 * Math.PI;
    const centerX = w / 2;
    const centerY = h / 2 - 10;
    const radius = 65;

    // ISL Slice
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, 0, islAngle);
    ctx.fillStyle = "#2563eb";
    ctx.fill();

    // ASL Slice
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, islAngle, 2 * Math.PI);
    ctx.fillStyle = "#7c3aed";
    ctx.fill();

    // Donut hole
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.55, 0, 2 * Math.PI);
    ctx.fillStyle = "#ffffff";
    ctx.fill();

    // Legend
    ctx.font = "bold 12px sans-serif";
    ctx.fillStyle = "#2563eb";
    ctx.fillRect(centerX - 90, h - 25, 12, 12);
    ctx.fillText(`ISL: ${dist.ISL_percent || 65}%`, centerX - 70, h - 15);

    ctx.fillStyle = "#7c3aed";
    ctx.fillRect(centerX + 15, h - 25, 12, 12);
    ctx.fillText(`ASL: ${dist.ASL_percent || 35}%`, centerX + 35, h - 15);
  },

  renderModalitiesChart(modalities) {
    const canvas = document.getElementById("canvas-modalities");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const labels = ["IMAGE", "VIDEO", "WEBCAM", "EMERGENCY"];
    const values = labels.map(l => (modalities && modalities[l]) || 1);
    const maxVal = Math.max(...values, 5);

    const chartHeight = h - 60;
    const barWidth = 36;
    const spacing = (w - (barWidth * labels.length)) / (labels.length + 1);

    labels.forEach((label, idx) => {
      const val = values[idx];
      const barH = (val / maxVal) * chartHeight;
      const x = spacing + idx * (barWidth + spacing);
      const y = h - 35 - barH;

      ctx.fillStyle = "#3b82f6";
      ctx.fillRect(x, y, barWidth, barH);

      ctx.fillStyle = "#64748b";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(label.substring(0, 5), x + barWidth / 2, h - 15);

      ctx.fillStyle = "#0f172a";
      ctx.font = "bold 11px sans-serif";
      ctx.fillText(val, x + barWidth / 2, y - 6);
    });
  },

  renderBenchmarks(benchmarks) {
    const container = document.getElementById("benchmarks-container");
    if (!container || !benchmarks) return;

    container.innerHTML = Object.entries(benchmarks).map(([name, score]) => `
      <div class="benchmark-item">
        <span class="benchmark-name">${name.replace(/_/g, " ")} Classifier</span>
        <span class="benchmark-score">${score}% Accuracy</span>
      </div>
    `).join("");
  },

  renderRecentTable(recent) {
    const tbody = document.getElementById("recent-activity-tbody");
    if (!tbody) return;

    if (!recent || recent.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 1.5rem;">No translation records yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = recent.map(r => `
      <tr>
        <td><strong>${r.language || "ISL"}</strong></td>
        <td><span class="badge badge-primary">${r.input_type || "IMAGE"}</span></td>
        <td style="max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
          ${r.translated_text || (r.recognized_signs || []).join(", ") || "--"}
        </td>
        <td><span class="badge badge-success">${Math.round((r.confidence_avg || 0.85) * 100)}%</span></td>
        <td style="font-size: 0.8rem; color: var(--text-muted);">${(r.timestamp || "").split("T")[0] || "Recent"}</td>
      </tr>
    `).join("");
  }
};

document.addEventListener("DOMContentLoaded", () => Dashboard.init());
