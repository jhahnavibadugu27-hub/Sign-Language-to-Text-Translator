/**
 * SignBridge AI - Authentication & Session Manager
 */

const Auth = {
  init() {
    this.updateNav();
  },

  isLoggedIn() {
    return !!API.getToken();
  },

  async login(email, password) {
    const data = await API.post("/api/auth/login", { email, password });
    API.setToken(data.access_token);
    API.setUser(data.user);
    this.updateNav();
    return data;
  },

  async register(full_name, email, password, preferred_language = "ISL") {
    const data = await API.post("/api/auth/register", {
      full_name,
      email,
      password,
      preferred_language
    });
    API.setToken(data.access_token);
    API.setUser(data.user);
    this.updateNav();
    return data;
  },

  logout() {
    API.clearToken();
    this.updateNav();
    window.location.href = "login.html";
  },

  updateNav() {
    const authNav = document.getElementById("nav-auth-container");
    if (!authNav) return;

    if (this.isLoggedIn()) {
      const user = API.getUser() || { full_name: "Account" };
      authNav.innerHTML = `
        <span style="font-size: 0.85rem; font-weight: 600; color: var(--text-secondary); margin-right: 0.5rem;">
          ${user.full_name.split(' ')[0]}
        </span>
        <button class="btn btn-secondary btn-sm" onclick="Auth.logout()">Logout</button>
      `;
    } else {
      authNav.innerHTML = `
        <a href="login.html" class="btn btn-secondary btn-sm">Login</a>
        <a href="register.html" class="btn btn-primary btn-sm">Register</a>
      `;
    }
  }
};

document.addEventListener("DOMContentLoaded", () => {
  Auth.init();
});
