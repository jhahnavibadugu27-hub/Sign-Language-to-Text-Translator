/**
 * SignBridge AI - Emergency Mode Controller
 * Accessible, high-contrast, one-click emergency dispatch with immediate audio alert.
 */

const EmergencyMode = {
  init() {
    this.cards = document.querySelectorAll(".emergency-card");
    this.alertBanner = document.getElementById("emergency-banner");
    this.alertText = document.getElementById("emergency-alert-phrase");
    this.speakBtn = document.getElementById("btn-speak-emergency");
    this.stopAudioBtn = document.getElementById("btn-stop-emergency-audio");

    this.bindEvents();
  },

  bindEvents() {
    this.cards.forEach(card => {
      card.addEventListener("click", () => {
        const message = card.dataset.message;
        this.triggerAlert(message, card);
      });
    });

    if (this.speakBtn) {
      this.speakBtn.addEventListener("click", () => {
        const text = this.alertText ? this.alertText.textContent : "";
        SpeechEngine.speak(text, { rate: 0.9, pitch: 1.1, volume: 1.0 });
      });
    }

    if (this.stopAudioBtn) {
      this.stopAudioBtn.addEventListener("click", () => {
        SpeechEngine.stop();
      });
    }
  },

  async triggerAlert(message, selectedCard) {
    this.cards.forEach(c => c.classList.remove("active"));
    selectedCard.classList.add("active");

    const fullAlert = `Emergency Alert! ${message} Please send immediate assistance.`;

    // Display banner immediately
    if (this.alertBanner) {
      this.alertBanner.style.display = "block";
      this.alertText.textContent = fullAlert;
      this.alertBanner.scrollIntoView({ behavior: "smooth" });
    }

    // Audible speech synthesis immediately at maximum volume
    SpeechEngine.speak(fullAlert, { rate: 0.9, pitch: 1.1, volume: 1.0 });

    try {
      await API.post("/api/translation/emergency", {
        message: message,
        language: App.activeLanguage,
        manual_override: true
      });
      App.showToast("Emergency alert logged and broadcast initiated.", "error");
    } catch (err) {
      console.warn("[Emergency API Warning]:", err);
    }
  }
};

document.addEventListener("DOMContentLoaded", () => EmergencyMode.init());
