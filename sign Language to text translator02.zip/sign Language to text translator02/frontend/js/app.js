/**
 * SignBridge AI - Main Application Utilities
 */

const App = {
  activeLanguage: "ISL",

  init() {
    this.setupLanguageSelectors();
    this.highlightActiveNavLink();
  },

  setupLanguageSelectors() {
    const langButtons = document.querySelectorAll(".lang-btn");
    langButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        langButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        this.activeLanguage = btn.dataset.lang || "ISL";
        
        // Dispatch custom event for active page modules
        window.dispatchEvent(new CustomEvent("languageChanged", {
          detail: { language: this.activeLanguage }
        }));
      });
    });
  },

  highlightActiveNavLink() {
    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    const navLinks = document.querySelectorAll(".nav-item a");
    navLinks.forEach(link => {
      const href = link.getAttribute("href");
      if (href === currentPath || (currentPath === "" && href === "index.html")) {
        link.classList.add("active");
      }
    });
  },

  showToast(message, type = "info") {
    let toast = document.getElementById("app-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "app-toast";
      toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        right: 24px;
        padding: 12px 20px;
        background: #0f172a;
        color: white;
        border-radius: 8px;
        font-size: 0.9rem;
        font-weight: 500;
        z-index: 9999;
        box-shadow: 0 10px 15px -3px rgba(0,0,0,0.2);
        transition: opacity 0.3s ease;
      `;
      document.body.appendChild(toast);
    }

    if (type === "error") {
      toast.style.background = "#ef4444";
    } else if (type === "success") {
      toast.style.background = "#10b981";
    } else {
      toast.style.background = "#0f172a";
    }

    toast.textContent = message;
    toast.style.opacity = "1";

    setTimeout(() => {
      toast.style.opacity = "0";
    }, 3500);
  }
};

document.addEventListener("DOMContentLoaded", () => App.init());
