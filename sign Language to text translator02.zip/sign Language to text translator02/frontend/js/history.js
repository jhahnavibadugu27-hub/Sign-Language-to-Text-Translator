/**
 * SignBridge AI - Translation History Controller
 * Search, pagination, filtering, deletion, and CSV export.
 */

const HistoryModule = {
  currentPage: 1,
  limit: 10,
  totalPages: 1,
  searchQuery: "",
  selectedLanguage: "",
  selectedType: "",

  init() {
    this.tableBody = document.getElementById("history-tbody");
    this.searchInput = document.getElementById("history-search-input");
    this.langFilter = document.getElementById("filter-language");
    this.typeFilter = document.getElementById("filter-type");
    this.prevBtn = document.getElementById("btn-prev-page");
    this.nextBtn = document.getElementById("btn-next-page");
    this.pageInfo = document.getElementById("history-page-info");
    this.exportBtn = document.getElementById("btn-export-history");

    this.bindEvents();
    this.loadHistory();
  },

  bindEvents() {
    if (this.searchInput) {
      let debounceTimeout;
      this.searchInput.addEventListener("input", (e) => {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
          this.searchQuery = e.target.value.trim();
          this.currentPage = 1;
          this.loadHistory();
        }, 300);
      });
    }

    if (this.langFilter) {
      this.langFilter.addEventListener("change", (e) => {
        this.selectedLanguage = e.target.value;
        this.currentPage = 1;
        this.loadHistory();
      });
    }

    if (this.typeFilter) {
      this.typeFilter.addEventListener("change", (e) => {
        this.selectedType = e.target.value;
        this.currentPage = 1;
        this.loadHistory();
      });
    }

    if (this.prevBtn) {
      this.prevBtn.addEventListener("click", () => {
        if (this.currentPage > 1) {
          this.currentPage--;
          this.loadHistory();
        }
      });
    }

    if (this.nextBtn) {
      this.nextBtn.addEventListener("click", () => {
        if (this.currentPage < this.totalPages) {
          this.currentPage++;
          this.loadHistory();
        }
      });
    }

    if (this.exportBtn) {
      this.exportBtn.addEventListener("click", () => this.exportCSV());
    }
  },

  async loadHistory() {
    let url = `/api/history?page=${this.currentPage}&limit=${this.limit}`;
    if (this.selectedLanguage) url += `&language=${encodeURIComponent(this.selectedLanguage)}`;
    if (this.selectedType) url += `&input_type=${encodeURIComponent(this.selectedType)}`;
    if (this.searchQuery) url += `&search=${encodeURIComponent(this.searchQuery)}`;

    try {
      const data = await API.get(url);
      this.totalPages = data.total_pages || 1;
      this.renderTable(data.items);
      this.updatePagination(data);
    } catch (err) {
      console.error("[History Load Error]:", err);
    }
  },

  renderTable(items) {
    if (!this.tableBody) return;

    if (!items || items.length === 0) {
      this.tableBody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No matching translation logs found.</td></tr>`;
      return;
    }

    this.tableBody.innerHTML = items.map(item => `
      <tr>
        <td><strong>${item.language || "ISL"}</strong></td>
        <td><span class="badge ${item.input_type === 'EMERGENCY' ? 'badge-danger' : 'badge-primary'}">${item.input_type || "IMAGE"}</span></td>
        <td style="font-family: var(--font-mono); font-size: 0.85rem;">
          ${(item.recognized_signs || []).map(s => `<span class="badge badge-secondary" style="margin-right: 4px;">${s}</span>`).join("") || "--"}
        </td>
        <td style="max-width: 320px; font-weight: 500;">${item.translated_text || "--"}</td>
        <td><span class="badge badge-success">${Math.round((item.confidence_avg || 0.85) * 100)}%</span></td>
        <td style="font-size: 0.8rem; color: var(--text-muted);">${(item.timestamp || "").replace("T", " ").substring(0, 19)}</td>
        <td>
          <button class="btn btn-secondary btn-sm" onclick="HistoryModule.deleteRecord('${item.id || item._id}')" title="Delete">
            ✕
          </button>
        </td>
      </tr>
    `).join("");
  },

  updatePagination(data) {
    if (this.pageInfo) {
      this.pageInfo.textContent = `Showing page ${data.page} of ${data.total_pages} (${data.total} total)`;
    }
    if (this.prevBtn) this.prevBtn.disabled = data.page <= 1;
    if (this.nextBtn) this.nextBtn.disabled = data.page >= data.total_pages;
  },

  async deleteRecord(recordId) {
    if (!confirm("Are you sure you want to delete this translation record?")) return;

    try {
      await API.delete(`/api/history/${recordId}`);
      App.showToast("Record deleted.", "info");
      this.loadHistory();
    } catch (err) {
      App.showToast("Failed to delete record.", "error");
    }
  },

  async exportCSV() {
    try {
      const data = await API.get("/api/history?limit=1000");
      const items = data.items || [];
      if (items.length === 0) {
        App.showToast("No records available to export.", "error");
        return;
      }

      const headers = ["Language", "Input Type", "Recognized Signs", "Translated Text", "Confidence", "Timestamp"];
      const rows = items.map(i => [
        i.language,
        i.input_type,
        `"${(i.recognized_signs || []).join("; ")}"`,
        `"${(i.translated_text || "").replace(/"/g, '""')}"`,
        i.confidence_avg,
        i.timestamp
      ]);

      const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `SignBridge_History_${new Date().toISOString().split("T")[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      App.showToast("Failed to export CSV.", "error");
    }
  }
};

document.addEventListener("DOMContentLoaded", () => HistoryModule.init());
