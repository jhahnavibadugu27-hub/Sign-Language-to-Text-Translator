/**
 * SignBridge AI - Live Webcam Translator Controller
 * Manages video stream, offscreen canvas frame extraction, WebSocket bidirectional stream,
 * landmark skeleton rendering overlay, and debounced text synthesis.
 */

const LiveTranslator = {
  videoStream: null,
  socket: null,
  isStreaming: false,
  frameInterval: null,

  init() {
    this.videoElem = document.getElementById("webcam-video");
    this.overlayCanvas = document.getElementById("overlay-canvas");
    this.ctx = this.overlayCanvas ? this.overlayCanvas.getContext("2d") : null;
    this.toggleCameraBtn = document.getElementById("btn-toggle-camera");
    
    // Status badges
    this.statusBadge = document.getElementById("live-status-badge");
    this.liveDot = document.getElementById("live-status-dot");
    this.statusText = document.getElementById("live-status-text");

    // Live results elements
    this.currentSignElem = document.getElementById("live-current-sign");
    this.confidenceElem = document.getElementById("live-confidence-val");
    this.tokenRibbon = document.getElementById("live-token-ribbon");
    this.sentenceElem = document.getElementById("live-sentence");

    // Controls
    this.clearBtn = document.getElementById("btn-live-clear");
    this.undoBtn = document.getElementById("btn-live-undo");
    this.speakBtn = document.getElementById("btn-live-speak");
    this.saveBtn = document.getElementById("btn-live-save");

    this.bindEvents();
  },

  bindEvents() {
    if (this.toggleCameraBtn) {
      this.toggleCameraBtn.addEventListener("click", () => this.toggleCamera());
    }

    if (this.clearBtn) {
      this.clearBtn.addEventListener("click", () => this.sendSocketMessage({ type: "clear" }));
    }

    if (this.undoBtn) {
      this.undoBtn.addEventListener("click", () => this.sendSocketMessage({ type: "undo" }));
    }

    if (this.speakBtn) {
      this.speakBtn.addEventListener("click", () => {
        const text = this.sentenceElem ? this.sentenceElem.textContent : "";
        SpeechEngine.speak(text);
      });
    }

    if (this.saveBtn) {
      this.saveBtn.addEventListener("click", () => this.sendSocketMessage({ type: "save" }));
    }

    window.addEventListener("languageChanged", (e) => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.sendSocketMessage({ type: "config", language: e.detail.language });
      }
    });

    // Cleanup resources on page unload
    window.addEventListener("beforeunload", () => this.stopCamera());
  },

  async toggleCamera() {
    if (this.isStreaming) {
      this.stopCamera();
    } else {
      await this.startCamera();
    }
  },

  async startCamera() {
    try {
      this.videoStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, frameRate: { ideal: 20 } },
        audio: false
      });

      this.videoElem.srcObject = this.videoStream;
      await this.videoElem.play();

      this.overlayCanvas.width = this.videoElem.videoWidth || 640;
      this.overlayCanvas.height = this.videoElem.videoHeight || 480;

      this.isStreaming = true;
      this.toggleCameraBtn.classList.remove("btn-primary");
      this.toggleCameraBtn.classList.add("btn-danger");
      this.toggleCameraBtn.textContent = "Stop Camera";

      this.statusText.textContent = "Live Stream Active";
      this.liveDot.style.background = "#10b981";
      this.liveDot.style.boxShadow = "0 0 8px #10b981";

      this.initWebSocket();
      this.startFrameLoop();
      App.showToast("Camera started. Align hands within frame.", "success");
    } catch (err) {
      console.error("[Camera Error]:", err);
      App.showToast("Camera access denied or device unavailable.", "error");
    }
  },

  stopCamera() {
    this.isStreaming = false;
    if (this.frameInterval) {
      clearInterval(this.frameInterval);
      this.frameInterval = null;
    }

    if (this.videoStream) {
      this.videoStream.getTracks().forEach(track => track.stop());
      this.videoStream = null;
    }

    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }

    if (this.ctx) {
      this.ctx.clearRect(0, 0, this.overlayCanvas.width, this.overlayCanvas.height);
    }

    this.toggleCameraBtn.classList.remove("btn-danger");
    this.toggleCameraBtn.classList.add("btn-primary");
    this.toggleCameraBtn.textContent = "Start Camera";

    this.statusText.textContent = "Camera Inactive";
    this.liveDot.style.background = "#ef4444";
    this.liveDot.style.boxShadow = "0 0 8px #ef4444";
  },

  initWebSocket() {
    const wsProto = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host || "127.0.0.1:8000";
    const wsUrl = `${wsProto}//${host}/ws/live-translate`;

    this.socket = new WebSocket(wsUrl);

    this.socket.onopen = () => {
      this.sendSocketMessage({ type: "config", language: App.activeLanguage });
    };

    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleSocketEvent(data);
    };

    this.socket.onerror = (err) => {
      console.warn("[WebSocket Error]:", err);
    };

    this.socket.onclose = () => {
      if (this.isStreaming) {
        console.log("[WebSocket] Reconnecting...");
        setTimeout(() => this.initWebSocket(), 2000);
      }
    };
  },

  sendSocketMessage(payload) {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(payload));
    }
  },

  startFrameLoop() {
    const offscreen = document.createElement("canvas");
    offscreen.width = 320;
    offscreen.height = 240;
    const offCtx = offscreen.getContext("2d");

    // Capture and dispatch frames every 80ms (~12.5 fps)
    this.frameInterval = setInterval(() => {
      if (!this.isStreaming || !this.socket || this.socket.readyState !== WebSocket.OPEN) return;

      offCtx.drawImage(this.videoElem, 0, 0, offscreen.width, offscreen.height);
      const b64 = offscreen.toDataURL("image/jpeg", 0.65);

      this.sendSocketMessage({
        type: "frame",
        image: b64,
        language: App.activeLanguage
      });
    }, 80);
  },

  handleSocketEvent(data) {
    if (data.type === "prediction") {
      const res = data.result;
      if (res && res.active) {
        this.currentSignElem.textContent = res.sign || "--";
        this.confidenceElem.textContent = `${Math.round((res.confidence || 0) * 100)}%`;

        if (res.sentence) {
          this.sentenceElem.textContent = res.sentence;
        }

        // Render token ribbon
        if (res.tokens) {
          this.tokenRibbon.innerHTML = res.tokens.map(t => `
            <div class="ribbon-token">${t.replace(/_/g, " ")}</div>
          `).join("");
        }
      }

      // Draw skeleton landmarks on top of webcam feed
      this.drawLandmarksOverlay(data.landmarks);
    } else if (data.type === "cleared" || data.type === "undone") {
      this.sentenceElem.textContent = data.sentence || "";
      this.tokenRibbon.innerHTML = (data.tokens || []).map(t => `
        <div class="ribbon-token">${t.replace(/_/g, " ")}</div>
      `).join("");
    } else if (data.type === "saved") {
      App.showToast("Translation saved to history!", "success");
    }
  },

  drawLandmarksOverlay(landmarks) {
    if (!this.ctx || !landmarks) return;
    this.ctx.clearRect(0, 0, this.overlayCanvas.width, this.overlayCanvas.height);

    const w = this.overlayCanvas.width;
    const h = this.overlayCanvas.height;

    const hands = [
      { lms: landmarks.left_hand, color: "#38bdf8" },
      { lms: landmarks.right_hand, color: "#4ade80" }
    ];

    hands.forEach(({ lms, color }) => {
      if (!lms) return;

      this.ctx.fillStyle = color;
      this.ctx.strokeStyle = "#ffffff";
      this.ctx.lineWidth = 2;

      lms.forEach(pt => {
        const cx = pt.x * w;
        const cy = pt.y * h;
        this.ctx.beginPath();
        this.ctx.arc(cx, cy, 4, 0, 2 * Math.PI);
        this.ctx.fill();
        this.ctx.stroke();
      });
    });
  }
};

document.addEventListener("DOMContentLoaded", () => LiveTranslator.init());
