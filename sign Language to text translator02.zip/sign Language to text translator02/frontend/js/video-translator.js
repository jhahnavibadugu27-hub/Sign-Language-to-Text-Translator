/**
 * SignBridge AI - Video Translator Controller
 * Handles long video uploading, chunk tracking, real-time SSE progress, and transcript download.
 */

const VideoTranslator = {
  currentFile: null,
  activeJobId: null,
  eventSource: null,

  init() {
    this.dropzone = document.getElementById("video-dropzone");
    this.fileInput = document.getElementById("video-file-input");
    this.videoPlayer = document.getElementById("preview-video");
    this.playerContainer = document.getElementById("video-player-container");
    this.uploadPlaceholder = document.getElementById("video-empty-placeholder");
    this.startBtn = document.getElementById("btn-start-video");
    
    // Progress HUD
    this.progressCard = document.getElementById("video-progress-card");
    this.progressBar = document.getElementById("video-progress-bar");
    this.progressPct = document.getElementById("video-progress-pct");
    this.statusText = document.getElementById("video-status-text");
    this.chunkBadge = document.getElementById("video-chunk-badge");

    // Transcript elements
    this.timelineContainer = document.getElementById("transcript-timeline");
    this.finalSentenceBox = document.getElementById("video-final-sentence");
    this.speakBtn = document.getElementById("btn-speak-video");
    this.downloadTxtBtn = document.getElementById("btn-download-txt");
    this.downloadSrtBtn = document.getElementById("btn-download-srt");

    this.bindEvents();
  },

  bindEvents() {
    if (!this.dropzone) return;

    this.dropzone.addEventListener("click", () => this.fileInput.click());

    this.dropzone.addEventListener("dragover", (e) => {
      e.preventDefault();
      this.dropzone.classList.add("dragover");
    });

    this.dropzone.addEventListener("dragleave", () => {
      this.dropzone.classList.remove("dragover");
    });

    this.dropzone.addEventListener("drop", (e) => {
      e.preventDefault();
      this.dropzone.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        this.handleFile(e.dataTransfer.files[0]);
      }
    });

    this.fileInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        this.handleFile(e.target.files[0]);
      }
    });

    this.startBtn.addEventListener("click", () => this.startProcessing());

    if (this.speakBtn) {
      this.speakBtn.addEventListener("click", () => {
        const text = this.finalSentenceBox ? this.finalSentenceBox.textContent : "";
        SpeechEngine.speak(text);
      });
    }

    if (this.downloadTxtBtn) {
      this.downloadTxtBtn.addEventListener("click", () => {
        if (this.activeJobId) {
          window.open(`${API_BASE_URL}/api/jobs/${this.activeJobId}/download?format=txt`, "_blank");
        }
      });
    }

    if (this.downloadSrtBtn) {
      this.downloadSrtBtn.addEventListener("click", () => {
        if (this.activeJobId) {
          window.open(`${API_BASE_URL}/api/jobs/${this.activeJobId}/download?format=srt`, "_blank");
        }
      });
    }
  },

  handleFile(file) {
    this.currentFile = file;
    const url = URL.createObjectURL(file);
    this.videoPlayer.src = url;
    this.videoPlayer.style.display = "block";
    if (this.uploadPlaceholder) this.uploadPlaceholder.style.display = "none";
    this.startBtn.disabled = false;
  },

  async startProcessing() {
    if (!this.currentFile) return;

    this.startBtn.disabled = true;
    this.progressCard.style.display = "block";
    this.timelineContainer.innerHTML = `<div style="color: var(--text-muted); text-align: center; padding: 2rem 0;">Analyzing video chunks with MediaPipe...</div>`;

    const formData = new FormData();
    formData.append("file", this.currentFile);
    formData.append("language", App.activeLanguage);

    try {
      const initData = await API.post("/api/translation/video", formData);
      this.activeJobId = initData.job_id;
      App.showToast(`Processing job started: ${initData.job_id.substring(0, 8)}...`, "info");

      this.listenToProgress(this.activeJobId);
    } catch (err) {
      App.showToast(err.message || "Failed to start video processing.", "error");
      this.startBtn.disabled = false;
    }
  },

  listenToProgress(jobId) {
    const sseUrl = `${API_BASE_URL}/api/jobs/${jobId}/stream`;
    this.eventSource = new EventSource(sseUrl);

    this.eventSource.onmessage = (e) => {
      const data = JSON.parse(e.data);
      this.updateUI(data);

      if (data.status === "COMPLETED" || data.status === "FAILED") {
        this.eventSource.close();
        this.startBtn.disabled = false;

        if (data.status === "COMPLETED") {
          App.showToast("Video translation completed successfully!", "success");
          if (data.final_transcript && data.final_transcript.sentence) {
            SpeechEngine.speak(data.final_transcript.sentence);
          }
        } else {
          App.showToast(`Job failed: ${data.error || "Unknown error"}`, "error");
        }
      }
    };

    this.eventSource.onerror = () => {
      // Fallback to manual polling if SSE disconnects
      this.eventSource.close();
      this.pollJobStatus(jobId);
    };
  },

  async pollJobStatus(jobId) {
    const interval = setInterval(async () => {
      try {
        const data = await API.get(`/api/jobs/${jobId}`);
        this.updateUI(data);

        if (data.status === "COMPLETED" || data.status === "FAILED") {
          clearInterval(interval);
          this.startBtn.disabled = false;
        }
      } catch (err) {
        clearInterval(interval);
      }
    }, 1200);
  },

  updateUI(data) {
    const progress = data.progress || 0;
    this.progressBar.style.width = `${progress}%`;
    this.progressPct.textContent = `${progress}%`;
    this.statusText.textContent = data.status || "PROCESSING";
    this.chunkBadge.textContent = `Chunk ${data.current_chunk || 1} / ${data.total_chunks || 1}`;

    // Update Live Transcript Timeline
    if (data.partial_results && data.partial_results.length > 0) {
      this.timelineContainer.innerHTML = data.partial_results.map(item => `
        <div class="timeline-entry">
          <span class="timeline-time">${item.timestamp_str}</span>
          <span class="timeline-sign">${item.sign.replace(/_/g, " ")}</span>
          <span class="timeline-conf">${Math.round(item.confidence * 100)}% match</span>
        </div>
      `).join("");
      this.timelineContainer.scrollTop = this.timelineContainer.scrollHeight;
    }

    // Update Sentence Display
    if (data.final_transcript && data.final_transcript.sentence) {
      this.finalSentenceBox.textContent = data.final_transcript.sentence;
      if (this.downloadTxtBtn) this.downloadTxtBtn.disabled = false;
      if (this.downloadSrtBtn) this.downloadSrtBtn.disabled = false;
    } else if (data.preliminary_sentence) {
      this.finalSentenceBox.textContent = data.preliminary_sentence;
    }
  }
};

document.addEventListener("DOMContentLoaded", () => VideoTranslator.init());
