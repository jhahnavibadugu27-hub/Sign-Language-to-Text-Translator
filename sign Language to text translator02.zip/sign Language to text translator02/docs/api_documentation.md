# SignBridge AI – API Specification & Reference Guide

**Base URL**: `http://127.0.0.1:8000`  
**WebSocket URL**: `ws://127.0.0.1:8000/ws/live-translate`  
**Version**: `1.0.0`

---

## 1. Authentication Endpoints

### 1.1 Register User
- **Method**: `POST`
- **Path**: `/api/auth/register`
- **Request Body**:
```json
{
  "full_name": "Yagnesh Katukala",
  "email": "yagnesh@university.edu",
  "password": "SecurePassword123!",
  "preferred_language": "ISL"
}
```
- **Response** (`200 OK`):
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user": {
    "id": "65e4f...",
    "full_name": "Yagnesh Katukala",
    "email": "yagnesh@university.edu",
    "preferred_language": "ISL",
    "created_at": "2026-11-03T11:15:00"
  }
}
```

### 1.2 User Login
- **Method**: `POST`
- **Path**: `/api/auth/login`
- **Request Body**:
```json
{
  "email": "yagnesh@university.edu",
  "password": "SecurePassword123!"
}
```
- **Response** (`200 OK`): Returns JWT access token and user profile.

### 1.3 Get Current User Profile
- **Method**: `GET`
- **Path**: `/api/auth/me`
- **Headers**: `Authorization: Bearer <token>`
- **Response** (`200 OK`): Returns authenticated profile details.

---

## 2. Translation Endpoints

### 2.1 Get Supported Languages Metadata
- **Method**: `GET`
- **Path**: `/api/translation/languages`
- **Response** (`200 OK`):
```json
{
  "languages": [
    {
      "code": "ISL",
      "name": "Indian Sign Language",
      "grammar": "Subject-Object-Verb (SOV) / Topic-Comment",
      "static_classes_count": 14,
      "dynamic_classes_count": 10,
      "is_primary": true
    },
    {
      "code": "ASL",
      "name": "American Sign Language",
      "grammar": "Subject-Verb-Object (SVO) / Topic-Comment",
      "static_classes_count": 15,
      "dynamic_classes_count": 8,
      "is_primary": false
    }
  ]
}
```

### 2.2 Translate Static Sign Image
- **Method**: `POST`
- **Path**: `/api/translation/image`
- **Content-Type**: `multipart/form-data`
- **Parameters**:
  - `file`: Image binary (JPEG/PNG, max 10MB)
  - `language`: `"ISL"` or `"ASL"`
- **Response** (`200 OK`):
```json
{
  "success": true,
  "sign": "NAMASTE",
  "confidence": 0.9412,
  "sentence": "Greetings and respect to you.",
  "language": "ISL",
  "is_emergency": false,
  "probabilities": {
    "NAMASTE": 0.9412,
    "B": 0.0315,
    "YES": 0.0124
  },
  "hands_detected": 2,
  "annotated_image": "data:image/jpeg;base64,...",
  "processing_time_ms": 14.8
}
```

### 2.3 Submit Video for Chunked Processing
- **Method**: `POST`
- **Path**: `/api/translation/video`
- **Content-Type**: `multipart/form-data`
- **Parameters**:
  - `file`: Video binary (MP4/WebM/MOV)
  - `language`: `"ISL"` or `"ASL"`
- **Response** (`200 OK`):
```json
{
  "job_id": "f81d4fae-7dec-11d0-a765-00a0c91e6bf6",
  "status": "QUEUED",
  "filename": "sign_session.mp4",
  "language": "ISL",
  "message": "Video uploaded successfully. Chunked background processing has started."
}
```

### 2.4 Trigger Emergency Alert
- **Method**: `POST`
- **Path**: `/api/translation/emergency`
- **Request Body**:
```json
{
  "message": "I need urgent medical help and doctor assistance.",
  "language": "ISL",
  "manual_override": true
}
```
- **Response** (`200 OK`):
```json
{
  "success": true,
  "alert_id": "EMERG-20261103112000",
  "message": "I need urgent medical help and doctor assistance.",
  "spoken_phrase": "Emergency Alert! I need urgent medical help and doctor assistance. Please send immediate assistance.",
  "timestamp": "2026-11-03T11:20:00.123456",
  "contact_action": "Emergency helpline contacts notified. Audio siren initiated."
}
```

---

## 3. Video Jobs & Streaming Endpoints

### 3.1 Get Job Status & Partial Results
- **Method**: `GET`
- **Path**: `/api/jobs/{job_id}`
- **Response** (`200 OK`):
```json
{
  "job_id": "f81d4fae-...",
  "status": "PROCESSING",
  "progress": 65,
  "language": "ISL",
  "filename": "demo.mp4",
  "current_chunk": 5,
  "total_chunks": 8,
  "partial_results": [
    { "timestamp_sec": 0.0, "timestamp_str": "00:00", "sign": "HELLO", "confidence": 0.92 },
    { "timestamp_sec": 2.0, "timestamp_str": "00:02", "sign": "HOW_ARE_YOU", "confidence": 0.88 }
  ],
  "preliminary_sentence": "Hello! How are you doing?",
  "final_transcript": null
}
```

### 3.2 Live Progress Server-Sent Events (SSE)
- **Method**: `GET`
- **Path**: `/api/jobs/{job_id}/stream`
- **Header**: `Accept: text/event-stream`
- **Stream Output**: Emits `data: { ... }` event payloads every time chunk progress advances.

### 3.3 Download Generated Transcripts
- **Method**: `GET`
- **Path**: `/api/jobs/{job_id}/download?format=txt` or `format=srt`
- **Response**: File stream (`text/plain` or `application/x-subrip`).

---

## 4. Real-Time WebSocket Interface

- **Endpoint**: `ws://127.0.0.1:8000/ws/live-translate`

### Client Message Types
- **Ping**: `{"type": "ping"}` $\to$ Server responds `{"type": "pong"}`
- **Config**: `{"type": "config", "language": "ISL"}`
- **Frame**: `{"type": "frame", "image": "data:image/jpeg;base64,...", "language": "ISL"}`
- **Clear**: `{"type": "clear"}`
- **Undo**: `{"type": "undo"}`
- **Save**: `{"type": "save"}`

### Server Stream Output
```json
{
  "type": "prediction",
  "language": "ISL",
  "hands_detected": 2,
  "landmarks": {
    "left_hand": [{ "x": 0.42, "y": 0.55, "z": -0.02 }, ...],
    "right_hand": [{ "x": 0.58, "y": 0.54, "z": -0.01 }, ...]
  },
  "result": {
    "active": true,
    "sign": "NAMASTE",
    "confidence": 0.935,
    "tokens": ["HELLO", "NAMASTE"],
    "sentence": "Hello, welcome. Greetings and respect to you."
  }
}
```
