# SignBridge AI – Two-Member Engineering Distribution

This document outlines the strict division of responsibilities between the two team members developing **SignBridge AI** for academic evaluation and hackathon submission.

---

## Member 1: AI/ML, Computer Vision & Python Backend Engineering

### Core Modules Owned:
1. **Computer Vision & Landmark Pipelines**:
   - Google MediaPipe Tasks integration (`hand_landmarker.task`, `pose_landmarker.task`).
   - Landmark coordinate extraction for both hands (21 keypoints each) and upper torso (7 keypoints).
   - 150-dimensional coordinate normalization engine (wrist centering and Euclidean palm-span scaling).
2. **AI/ML Model Development**:
   - Dataset research and verified vocabulary curation for ISL and ASL.
   - Training and hyperparameter tuning of Random Forest classifiers (120 estimators) for static signs.
   - Training of PyTorch Bidirectional LSTM (`Bi-LSTM`) sequence models with temporal attention for dynamic continuous signs.
   - Empirical evaluation metrics generation (accuracy, precision, recall, F1, confusion matrices).
3. **Backend & Distributed Job Management**:
   - FastAPI REST API and Starlette WebSocket server.
   - Memory-safe chunked video processing worker with uniform 15 fps sampling.
   - Server-Sent Events (SSE) streaming for incremental video translation progress.
   - MongoDB database integration and resilient in-memory fallback layer.
   - JWT authentication and Bcrypt password hashing.

---

## Member 2: Frontend Engineering, UI/UX & System Integration

### Core Modules Owned:
1. **Frontend Architecture & Design System**:
   - Clean, modern SaaS UI/UX using HTML5 and CSS3 (no external heavy frameworks).
   - Unified CSS custom properties design tokens (`style.css`, `responsive.css`).
   - Implementation of 10 dedicated web pages:
     - `index.html` (Landing & Modalities Showcase)
     - `image-translator.html` (Image Studio & Landmark HUD)
     - `video-translator.html` (Chunked Video Translation Studio)
     - `live-translator.html` (Real-Time WebSocket Webcam)
     - `emergency.html` (Priority Emergency HUD)
     - `dashboard.html` (Telemetry & Performance Dashboard)
     - `history.html` (Database Audit Logs & CSV Export)
     - `login.html` & `register.html` (Authentication)
     - `about.html` (Project Report & Architecture)
2. **Real-Time Client & Hardware Integration**:
   - Web MediaDevices camera access loop and offscreen canvas downsampler.
   - HTML5 Canvas landmark skeleton overlay rendering.
   - WebSocket client communication and reconnect handling.
   - Web SpeechSynthesis audio engine with voice pitch and rate modulation.
   - Emergency mode one-click dispatch and siren audio alerts.
   - Dashboard HTML5 Canvas telemetry charts (doughnut and bar charts).
