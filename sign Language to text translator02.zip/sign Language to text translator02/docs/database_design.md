# SignBridge AI – MongoDB Database Architecture & Schema Specification

**Database Name**: `signbridge_ai`  
**Driver**: `pymongo` with resilient In-Memory proxy fallback

---

## 1. Collections Overview

| Collection | Purpose | Key Indices |
| :--- | :--- | :--- |
| `users` | User credentials & authentication profiles | `email` (Unique), `_id` |
| `translation_history` | Audit log of all completed translations | `user_id`, `language`, `timestamp` (Desc), `input_type` |
| `translation_jobs` | Video background chunk processing queue | `job_id` (Unique), `status`, `created_at` |
| `translation_sessions`| Active webcam and real-time live sessions | `session_uuid` (Unique), `user_id` |
| `user_preferences` | Client TTS voice, speech rate & emergency contacts | `user_id` (Unique) |

---

## 2. Collection Schemas

### 2.1 `users`
```json
{
  "_id": "ObjectId",
  "full_name": "string (min: 2, max: 100)",
  "email": "string (lowercase, unique)",
  "password_hash": "string (bcrypt hash with random salt)",
  "preferred_language": "string ('ISL' or 'ASL')",
  "created_at": "ISO 8601 Datetime String"
}
```

### 2.2 `translation_history`
```json
{
  "_id": "ObjectId",
  "user_id": "string | null (optional foreign reference)",
  "language": "string ('ISL' or 'ASL')",
  "input_type": "string ('IMAGE', 'VIDEO', 'WEBCAM', 'EMERGENCY')",
  "recognized_signs": ["array of uppercase string tokens"],
  "translated_text": "string (synthesized natural English sentence)",
  "confidence_avg": "float (0.000 to 1.000)",
  "processing_time_ms": "float",
  "filename": "string | null (for video uploads)",
  "timestamp": "ISO 8601 Datetime String"
}
```

### 2.3 `translation_jobs`
```json
{
  "_id": "ObjectId",
  "job_id": "string (UUID4 format, unique)",
  "user_id": "string | null",
  "filename": "string (original uploaded filename)",
  "file_path": "string (absolute path in storage/uploads/)",
  "language": "string ('ISL' or 'ASL')",
  "status": "string ('QUEUED', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED')",
  "progress": "integer (0 to 100)",
  "current_chunk": "integer",
  "total_chunks": "integer",
  "partial_results": [
    {
      "timestamp_sec": "float",
      "timestamp_str": "string (MM:SS)",
      "sign": "string",
      "confidence": "float"
    }
  ],
  "preliminary_sentence": "string",
  "final_transcript": {
    "sentence": "string",
    "tokens_count": "integer",
    "duration_sec": "float",
    "srt_download_url": "string",
    "txt_download_url": "string",
    "detailed_signs": "array"
  },
  "error": "string | null",
  "created_at": "ISO 8601 Datetime String"
}
```

---

## 3. Resilient In-Memory Fallback Mechanism

In standard production environments, SignBridge AI connects to `mongodb://localhost:27017`. 

To ensure **100% operational uptime** when deployed in diverse academic evaluation environments or hackathon presentation laptops where a local MongoDB daemon might not be pre-configured:
1. `DatabaseManager` attempts a non-blocking `ping` command with a 1.5-second timeout.
2. If MongoDB is unresponsive, it automatically intercepts all collection calls with an `InMemoryDatabase` instance.
3. The in-memory proxy supports:
   - `insert_one(doc)`
   - `find(query, sort, limit, skip)`
   - `find_one(query)`
   - `update_one(query, update)`
   - `delete_one(query)`
   - `count_documents(query)`
4. This guarantees that user registration, login, video job tracking, history auditing, and telemetry dashboard charts function flawlessly during demonstrations without throwing unhandled database connection errors.
