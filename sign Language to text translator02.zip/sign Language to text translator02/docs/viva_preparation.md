# SignBridge AI – Technical Viva & Evaluation Defense Guide

This document is prepared specifically for academic project evaluations, viva-voce examinations, and hackathon technical presentations.

---

### Q1: Why did you build independent pipelines for ISL and ASL instead of a universal sign language model?
**Answer:**
Sign language is not universal. Indian Sign Language (ISL) and American Sign Language (ASL) have completely independent linguistic and syntactic rules:
1. **Alphabet Morphology**: ISL fingerspelling is two-handed (both hands interact to form letters like A, B, C, D), whereas ASL is one-handed.
2. **Grammar Syntax**: ISL generally follows Subject-Object-Verb (SOV) order or Topic-Comment syntax, while ASL follows Subject-Verb-Object (SVO) order.
3. **Lexical Gestures**: The sign for "Water", "Namaste", or "Help" in ISL utilizes distinct dual-hand spatial gestures that do not exist in ASL.
Conflating them into a single classifier causes cross-lingual contamination and severe false positives. SignBridge AI uses separate vocabularies, coordinate spaces, and model weights.

---

### Q2: How does your system handle lengthy continuous videos without crashing server memory?
**Answer:**
Traditional implementations attempt to decode an entire video file into RAM as a massive 4D numpy array (`Frames x H x W x C`), which crashes on videos longer than a few seconds.

SignBridge AI implements a **chunked sliding-window pipeline**:
1. It reads video metadata and slices the temporal timeline into overlapping windows of **2.0 seconds with a 0.5-second step**.
2. For each chunk, frames are uniformly decimated to **15 frames per second** (sampling exactly 30 frames per window).
3. OpenCV seeks directly to the target frame index (`cv2.CAP_PROP_POS_FRAMES`), extracting and processing only 30 frames at a time with MediaPipe Tasks.
4. Extracted 150-dimensional sequence arrays are evaluated by our PyTorch Bi-LSTM.
5. Recognized tokens are deduplicated using **Run-Length Encoding (RLE) and temporal hysteresis**, and streamed to the user via **Server-Sent Events (SSE)** before subsequent chunks are processed.
6. Memory utilization remains strictly bounded and constant regardless of whether the video is 10 seconds or 15 minutes long.

---

### Q3: How do you normalize landmarks to make the model invariant to signer distance and position?
**Answer:**
Raw pixel coordinates $(x, y, z)$ change drastically if a user stands closer or further from the camera, or moves to the corner of the frame. 

Our normalization module performs a two-stage mathematical transformation:
1. **Wrist-Origin Translation**: Every hand landmark $P_i = (x_i, y_i, z_i)$ is translated relative to the wrist landmark $P_0$:
   $$\hat{P}_i = P_i - P_0$$
   This makes the coordinate space translation-invariant.
2. **Euclidean Palm-Span Scaling**: We calculate the Euclidean distance $d$ between the wrist (index 0) and the middle finger MCP joint (index 9):
   $$d = \sqrt{(\hat{x}_9)^2 + (\hat{y}_9)^2}$$
   We then divide all translated coordinates by $d$:
   $$P_{\text{norm}, i} = \frac{\hat{P}_i}{d}$$
   This guarantees complete scale invariance regardless of whether the user is 2 feet or 6 feet away from the lens.
3. The upper torso pose is similarly centered on the shoulder midpoint and scaled by shoulder span.

---

### Q4: Why did you select a Bi-LSTM rather than a 3D CNN or heavy Video Transformer?
**Answer:**
1. **Geometric Coordinate vs. Raw Pixel Efficiency**: 3D CNNs (like I3D or SlowFast) process raw RGB video frames ($30 \times 224 \times 224 \times 3 \approx 4.5\text{ million floats}$), requiring high-end dedicated GPUs. By extracting 3D skeletal landmarks first with MediaPipe, our input is reduced to $(30 \times 150 = 4,500\text{ floats})$ — a **$1000\times$ reduction in computational bandwidth**.
2. **Bidirectional Temporal Context**: Sign language gestures have distinct phases: preparation, stroke (peak meaning), and retraction. A Bidirectional LSTM processes the sequence forward and backward simultaneously, capturing temporal dependencies across the whole motion window.
3. **Temporal Attention**: The attention mechanism weights the most informative frames (the stroke phase) higher than transitional frames.
4. **Latency**: The Bi-LSTM executes inference in under 5 milliseconds on standard commodity CPU hardware, enabling sub-50ms real-time WebSocket inference.

---

### Q5: How do you prevent predictions from flickering wildly in live webcam mode?
**Answer:**
We implement **state hysteresis and multi-frame dwell filtering**:
- Raw predictions from individual frames fluctuate due to motion blur or landmark jitter.
- The WebSocket session maintains a circular history buffer of recent predictions.
- A sign is only committed to the sentence buffer if it satisfies two conditions:
  1. The confidence score exceeds the threshold ($\ge 0.60$).
  2. The same sign token appears in at least **2 out of the last 3 consecutive inferences**.
- Consecutive duplicate runs of the same sign are collapsed, preventing the same gesture from being appended 30 times while the user holds their hand steady.

---

### Q6: How does the application persist data, and what happens if MongoDB is offline?
**Answer:**
SignBridge AI connects to MongoDB (`mongodb://localhost:27017/signbridge_ai`) via PyMongo, storing `users`, `translation_history`, `translation_jobs`, and `user_preferences`.
To ensure resilience during hackathons or viva demonstrations where MongoDB might not be running as a background service on the evaluator's machine, our `DatabaseManager` implements an **automated in-memory fallback database**. It provides full PyMongo-compatible CRUD methods (`insert_one`, `find`, `update_one`, `delete_one`, `count_documents`), allowing all features, authentication, and history logging to function without crashing.

---

### Q7: How does sentence construction work for sign language?
**Answer:**
Sign language tokens do not map 1:1 to written English grammar. For instance, in ISL, a user might sign:
$$\text{["I", "WATER", "WANT"]}$$
Our `SentenceService` applies language-specific rule dictionaries:
- Identifies conversational sign clusters and maps them into fluent English sentences:
  $$\text{["I", "WATER", "WANT"]} \longrightarrow \text{"I would like some drinking water."}$$
  $$\text{["HELP", "POLICE"]} \longrightarrow \text{"I need urgent help, please call the police immediately!"}$$
- Single tokens are expanded into meaningful utterances (e.g., `"NAMASTE"` $\to$ `"Greetings and respect to you."`).
- Sentence strings are capitalized, punctuated, and forwarded to the browser's native `SpeechSynthesis` audio engine.
