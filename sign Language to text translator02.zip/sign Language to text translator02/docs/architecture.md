# SignBridge AI – Technical Architecture & Engineering Specification

## 1. Project Overview & Executive Summary
**SignBridge AI** is an advanced, multimodal sign language translation platform engineered to bridge communication barriers between the Deaf and Hard of Hearing (DHH) community and the hearing populace. 

Unlike conventional toy projects that merely perform static 2D bounding-box classification for a few fingerspelling letters, SignBridge AI addresses both **Indian Sign Language (ISL)** and **American Sign Language (ASL)** with separate visual grammars, gesture dynamics, and vocabularies. It features continuous video translation, chunked asynchronous stream processing, real-time bidirectional WebSocket live inference, and an accessible Emergency Assistance mode.

---

## 2. Problem Statement & Objectives

### The Problem
- **Linguistic Marginalization**: Over 63 million people in India and millions globally face communication deficits due to a scarcity of certified sign language interpreters.
- **ISL vs. ASL Divergence**: Most research and public models focus almost exclusively on ASL fingerspelling. ISL uses two-handed manual alphabets, distinct lexical signs, head/facial morphology, and unique grammatical spatial syntax (Subject-Object-Verb / Topic-Comment) compared to ASL (Subject-Verb-Object).
- **Processing Continuous Video**: Real sign language is fluid. Traditional frame-by-frame classifiers produce choppy, redundant, and incoherent output when applied to continuous video feeds.

### Key Objectives
1. **Bilingual Dual-Pipeline Engine**: Build independent processing pipelines for ISL and ASL with strictly separated vocabularies, landmark feature representations, and models.
2. **Three Input Modalities**: High-resolution image analysis, long-form chunked video processing with incremental updates, and low-latency webcam streaming.
3. **Continuous Video Pipeline**: Window-based temporal chunking with overlap smoothing to convert multi-sign continuous videos into timestamped readable transcripts.
4. **Resilient Production Stack**: Modern HTML5/CSS3/Vanilla JS frontend (no heavy framework lock-in), asynchronous Python FastAPI backend, PyTorch & Scikit-Learn inference engines, and MongoDB persistence.
5. **Emergency Mode**: High-contrast, rapid-access interface for critical communication (medical, emergency assistance, hazard alerting) with voice synthesis.

---

## 3. High-Level System Architecture

```mermaid
flowchart TD
    subgraph Client["Frontend Layer (HTML5 / CSS3 / Vanilla JS)"]
        UI_Home["Home Page"]
        UI_Img["Image Translator"]
        UI_Vid["Video Translator (Chunked & Progress)"]
        UI_Live["Live Webcam (WebSocket / Canvas Stream)"]
        UI_Emerg["Emergency Mode (Priority HUD)"]
        UI_Dash["Analytics & History Dashboard"]
        TTS["Web SpeechSynthesis API Engine"]
    end

    subgraph Gateway["API Gateway & Real-time Layer (FastAPI)"]
        REST["REST API (Auth, Files, Jobs, History)"]
        WS["WebSocket Server (/ws/live-translate)"]
        AUTH["JWT / Security Middleware"]
        TASK_MGR["Async Background Task Manager"]
    end

    subgraph AIEngine["AI/ML Computer Vision Engine"]
        CV_PP["OpenCV Preprocessor & Frame Normalizer"]
        MP["MediaPipe Holistic & Hands Landmark Extractor"]
        NORM["Feature Normalization (Origin-relative & Scale Invariant)"]
        
        subgraph Models["Dual Recognition Models"]
            subgraph ISL_Pipe["ISL Recognition Pipeline"]
                ISL_Static["ISL Static Classifier (RandomForest / MLP)"]
                ISL_Dyn["ISL Dynamic Classifier (Bi-LSTM / GRU)"]
            end
            subgraph ASL_Pipe["ASL Recognition Pipeline"]
                ASL_Static["ASL Static Classifier (RandomForest / MLP)"]
                ASL_Dyn["ASL Dynamic Classifier (Bi-LSTM / GRU)"]
            end
        end
        
        SMOOTH["Temporal Window Smoothing & Debouncing"]
        NLP["Sentence Synthesizer & Boundary Detector"]
    end

    subgraph DataLayer["Persistence & Storage Layer"]
        MDB[("MongoDB Database (signbridge_ai)")]
        LOCAL_STORE["Local Storage (Uploads, Chunks, Transcripts)"]
    end

    UI_Img -->|HTTP POST Image| REST
    UI_Vid -->|HTTP POST Video| REST
    UI_Live <-->|WebSocket Stream / Landmarked Packets| WS
    UI_Emerg -->|High Priority Request| REST

    REST --> AUTH
    REST --> TASK_MGR
    TASK_MGR --> LOCAL_STORE
    TASK_MGR --> CV_PP

    WS --> NORM
    CV_PP --> MP --> NORM
    NORM --> Models
    Models --> SMOOTH --> NLP
    NLP -->|Incremental Events| WS
    NLP -->|Final Transcripts| TASK_MGR
    TASK_MGR --> MDB
    REST --> MDB
    NLP -.->|Audio playback trigger| TTS
```

---

## 4. Multimodal Processing Workflows

### 4.1 Image-to-Text Workflow
```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Browser as Frontend (Image Translator)
    participant API as FastAPI Backend
    participant CV as OpenCV + MediaPipe
    participant Model as ISL/ASL Static Classifier
    participant DB as MongoDB

    User->>Browser: Selects file (JPG/PNG) & chooses Language (ISL/ASL)
    Browser->>API: POST /api/translation/image (multipart form-data)
    API->>API: Validate MIME type, size (<10MB) & header integrity
    API->>CV: Decode image buffer & execute MediaPipe Landmark Extraction
    alt No hands/body detected
        CV-->>API: LandmarkDetectionError ("No landmarks detected")
        API-->>Browser: 422 Unprocessable Entity (Friendly visual guidance)
    else Hands Detected
        CV->>CV: Normalize coordinates relative to wrist & bounding span
        CV->>Model: Forward feature vector (150 features)
        Model-->>API: Top prediction, confidence score, class probabilities
        API->>DB: Record translation in translation_history
        API-->>Browser: JSON response (gesture, confidence, sentence, metadata)
        Browser->>Browser: Render visual keypoints overlay on canvas
        Browser->>User: Play SpeechSynthesis audio & display results
    end
```

### 4.2 Long Video Processing & Chunking Workflow
Continuous video processing handles arbitrary length videos without exceeding memory limits:

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Web as Frontend (Video Translator)
    participant JobAPI as FastAPI Job Service
    participant Worker as Background Async Pipeline
    participant CV_MP as Frame Decimation & MediaPipe
    participant TempModel as Dynamic Sequence Model (Bi-LSTM)
    participant DB as MongoDB

    User->>Web: Uploads MP4/WebM video
    Web->>JobAPI: POST /api/translation/video
    JobAPI->>JobAPI: Generate unique job_id (UUID4), save file to storage/uploads
    JobAPI->>DB: Insert Job document (Status: QUEUED, Progress: 0%)
    JobAPI-->>Web: Return { job_id, status: "QUEUED" }
    
    Web->>Web: Initiate SSE listener on /api/jobs/{job_id}/stream
    
    JobAPI->>Worker: Dispatch background video task
    Worker->>DB: Update Status to "PROCESSING"
    
    loop Sliding Window Execution (2.0s window, 1.0s step, 15 fps sampling)
        Worker->>CV_MP: Read frame range [t_start, t_end] with uniform 15fps sampling
        CV_MP->>CV_MP: Extract 2-hand + upper-body pose landmark trajectories
        CV_MP->>TempModel: Sequence Tensor [1, Seq_Len=30, Features=150]
        TempModel-->>Worker: Predicted Sign + Window Confidence
        Worker->>Worker: Apply sliding-window majority voting & deduplication
        Worker->>DB: Append incremental sign & timestamp to translation_jobs
        Worker-->>Web: Push incremental event: { timestamp, sign, confidence, progress }
        Web->>Web: Update transcript UI & progress bar live
    end

    Worker->>Worker: Synthesize full coherent sentence & punctuation
    Worker->>DB: Mark status "COMPLETED", save final transcript & metrics
    Worker-->>Web: Final event with full transcript and download link
    Web->>User: Enable text-to-speech, export SRT/TXT transcript
```

---

## 5. Indian Sign Language (ISL) vs. American Sign Language (ASL)

| Dimension | Indian Sign Language (ISL) | American Sign Language (ASL) |
| :--- | :--- | :--- |
| **Alphabet / Fingerspelling** | Predominantly **two-handed** (both hands interact for vowels & consonants). | Strictly **one-handed** (dominant hand forms letters A–Z). |
| **Grammatical Order** | **SOV (Subject - Object - Verb)** or Topic-Comment structure. | **SVO (Subject - Verb - Object)** or Topic-Comment. |
| **Feature Vector Representation** | Dual-hand coordinates + upper-body torso keypoints = **150 features**. | Dominant-hand coordinates + non-dominant interaction = **150 features**. |
| **Model Independence** | Independent Random Forest static model & PyTorch Bi-LSTM trained on ISLRTC vocabulary. | Independent Random Forest static model & PyTorch Bi-LSTM trained on ASL/WLASL vocabulary. |
