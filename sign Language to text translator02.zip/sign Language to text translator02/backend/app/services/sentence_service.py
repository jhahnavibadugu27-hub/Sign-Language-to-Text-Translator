"""
SignBridge AI - Sentence Construction & Grammatical Synthesizer
Converts raw sign token sequences into natural, punctuated, and grammatically sound English sentences.
Respects distinct ISL (SOV) and ASL (SVO) structures.
"""

from typing import List, Dict, Any
import json
import os

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
DATASETS_DIR = os.path.join(BASE_DIR, "ai_engine", "datasets")


class SentenceService:
    """Transforms recognized sign sequences into readable English sentences."""

    def __init__(self):
        self.rules = {"ISL": {}, "ASL": {}}
        self._load_grammar_rules()

    def _load_grammar_rules(self):
        for lang in ["isl", "asl"]:
            vpath = os.path.join(DATASETS_DIR, f"{lang}_vocabulary.json")
            if os.path.exists(vpath):
                with open(vpath, "r") as f:
                    data = json.load(f)
                    self.rules[lang.upper()] = data.get("grammar_rules", {})

    def deduplicate_tokens(self, tokens: List[str], min_run_length: int = 1) -> List[str]:
        """
        Compresses consecutive duplicate tokens (e.g. ['HELLO', 'HELLO', 'WATER'] -> ['HELLO', 'WATER']).
        """
        if not tokens:
            return []

        cleaned = []
        for t in tokens:
            if not cleaned or cleaned[-1] != t:
                cleaned.append(t)
        return cleaned

    def synthesize_sentence(self, tokens: List[str], language: str = "ISL") -> str:
        """
        Synthesizes a readable sentence from a sequence of recognized signs.
        """
        cleaned = self.deduplicate_tokens(tokens)
        if not cleaned:
            return ""

        lang = language.upper()
        rules = self.rules.get(lang, {})

        # Single sign mapping
        if len(cleaned) == 1:
            token = cleaned[0]
            if token in rules:
                return rules[token]
            return f"{token.capitalize()}."

        # Compound sentence construction
        # Pattern-based matching for conversational sign clusters
        token_str = "_".join(cleaned)

        # Common multi-sign mappings
        composite_rules = {
            "HELLO_HOW_ARE_YOU": "Hello! How are you doing?",
            "I_AM_FINE_THANK_YOU": "I am doing fine, thank you very much.",
            "PLEASE_WATER": "Please give me some drinking water.",
            "NEED_HELP_POLICE": "I need urgent help, please call the police immediately!",
            "HELP_MEDICAL": "Emergency! I require medical assistance right now.",
            "DANGER_HELP": "Danger alert! Please send assistance immediately."
        }

        if token_str in composite_rules:
            return composite_rules[token_str]

        # Natural concatenation with grammatical smoothing
        words = []
        for t in cleaned:
            formatted = t.replace("_", " ").lower()
            words.append(formatted)

        sentence = " ".join(words)
        sentence = sentence[0].upper() + sentence[1:]
        if not sentence.endswith((".", "?", "!")):
            sentence += "."

        return sentence
