"""
SignBridge AI - Computer Vision & Inference Service
Bridges OpenCV, MediaPipe LandmarkExtractor, and Unified PredictionEngine.
"""

import cv2
import base64
import time
import numpy as np
from typing import Dict, Any, Optional

from ai_engine.preprocessing.landmark_extractor import LandmarkExtractor
from ai_engine.inference.prediction_engine import PredictionEngine
from backend.app.services.sentence_service import SentenceService


class CVService:
    def __init__(self):
        print("[CVService] Initializing LandmarkExtractor and PredictionEngine...")
        self.extractor = LandmarkExtractor()
        self.engine = PredictionEngine()
        self.sentence_svc = SentenceService()
        print("[CVService] Computer Vision services ready.")

    def process_image(self, image_bytes: bytes, language: str = "ISL") -> Dict[str, Any]:
        """
        Processes single uploaded sign image:
        Decodes -> Extracts landmarks -> Runs static prediction -> Renders overlay.
        """
        start_time = time.time()

        # Decode BGR image
        np_arr = np.frombuffer(image_bytes, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("Invalid or corrupted image format.")

        processed = self.extractor.process_frame(frame)
        hands_detected = processed["hands_detected"]

        if hands_detected == 0:
            return {
                "success": False,
                "hands_detected": 0,
                "message": "No hand gestures detected. Please ensure your hands are clearly visible in the camera frame.",
                "processing_time_ms": round((time.time() - start_time) * 1000, 2)
            }

        # Predict gesture
        pred = self.engine.predict_static(language, processed["feature_vector"])
        sign = pred["sign"]
        confidence = pred["confidence"]

        # Synthesize sentence
        sentence = self.sentence_svc.synthesize_sentence([sign], language=language)

        # Draw visual skeletal overlay
        annotated_bgr = self.extractor.draw_landmarks(frame, processed)

        # Draw HUD label box on annotated frame
        h, w, _ = annotated_bgr.shape
        hud_text = f"{language}: {sign} ({confidence*100:.1f}%)"
        cv2.rectangle(annotated_bgr, (20, 20), (360, 70), (20, 20, 20), -1)
        cv2.putText(annotated_bgr, hud_text, (30, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 180), 2)

        # Encode to Base64 JPEG for direct client display
        _, buffer = cv2.imencode(".jpg", annotated_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        b64_img = base64.b64encode(buffer).decode("utf-8")

        proc_time = round((time.time() - start_time) * 1000, 2)

        return {
            "success": True,
            "sign": sign,
            "confidence": round(confidence, 4),
            "sentence": sentence,
            "language": language.upper(),
            "is_emergency": pred.get("is_emergency", False),
            "probabilities": pred.get("probabilities", {}),
            "hands_detected": hands_detected,
            "annotated_image": f"data:image/jpeg;base64,{b64_img}",
            "landmarks": {
                "left_hand": processed["left_hand"],
                "right_hand": processed["right_hand"]
            },
            "processing_time_ms": proc_time
        }


cv_service = CVService()
