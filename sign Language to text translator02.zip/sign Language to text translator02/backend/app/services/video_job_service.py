"""
SignBridge AI - Asynchronous Chunked Video Processing Engine
Extracts temporal sliding-window chunks, runs PyTorch Bi-LSTM inference,
filters duplicate gestures, streams incremental partial results, and synthesizes transcripts.
"""

import os
import cv2
import time
import asyncio
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
import numpy as np

from backend.app.core.config import TRANSCRIPT_DIR
from backend.app.database.collections import jobs_col, history_col
from backend.app.services.cv_service import cv_service
from backend.app.services.sentence_service import SentenceService


def format_timestamp(seconds: float) -> str:
    """Formats float seconds into MM:SS format."""
    m = int(seconds // 60)
    s = int(seconds % 60)
    return f"{m:02d}:{s:02d}"


def format_srt_time(seconds: float) -> str:
    """Formats float seconds into SRT timestamp 00:00:00,000."""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


class VideoJobManager:
    """Manages asynchronous long-form video translation jobs."""

    def __init__(self):
        self.active_jobs: Dict[str, Dict[str, Any]] = {}
        self.subscribers: Dict[str, List[asyncio.Queue]] = {}
        self.sentence_svc = SentenceService()

    def create_job(self, filename: str, file_path: str, language: str = "ISL", user_id: Optional[str] = None) -> str:
        job_id = str(uuid.uuid4())
        job_data = {
            "job_id": job_id,
            "user_id": user_id,
            "filename": filename,
            "file_path": file_path,
            "language": language.upper(),
            "status": "QUEUED",
            "progress": 0,
            "current_chunk": 0,
            "total_chunks": 1,
            "partial_results": [],
            "preliminary_sentence": "",
            "final_transcript": None,
            "error": None,
            "created_at": datetime.now().isoformat()
        }

        self.active_jobs[job_id] = job_data
        jobs_col.insert_one(job_data)
        return job_id

    def cancel_job(self, job_id: str) -> bool:
        if job_id in self.active_jobs:
            self.active_jobs[job_id]["status"] = "CANCELLED"
            jobs_col.update_one({"job_id": job_id}, {"$set": {"status": "CANCELLED"}})
            return True
        return False

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        if job_id in self.active_jobs:
            return self.active_jobs[job_id]
        doc = jobs_col.find_one({"job_id": job_id})
        return doc

    async def subscribe(self, job_id: str) -> asyncio.Queue:
        queue = asyncio.Queue()
        if job_id not in self.subscribers:
            self.subscribers[job_id] = []
        self.subscribers[job_id].append(queue)
        return queue

    async def unsubscribe(self, job_id: str, queue: asyncio.Queue):
        if job_id in self.subscribers and queue in self.subscribers[job_id]:
            self.subscribers[job_id].remove(queue)

    async def broadcast(self, job_id: str, payload: Dict[str, Any]):
        if job_id in self.subscribers:
            for q in list(self.subscribers[job_id]):
                await q.put(payload)

    async def process_video_background(self, job_id: str):
        """
        Background task that runs chunked video processing.
        Does not block main event loop.
        """
        job = self.active_jobs.get(job_id)
        if not job:
            return

        job["status"] = "PROCESSING"
        jobs_col.update_one({"job_id": job_id}, {"$set": {"status": "PROCESSING"}})
        await self.broadcast(job_id, {"event": "status", "status": "PROCESSING", "progress": 5})

        video_path = job["file_path"]
        language = job["language"]

        # Run video extraction in a worker thread to keep asyncio responsive
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, self._execute_video_pipeline, job_id)
        except Exception as e:
            job["status"] = "FAILED"
            job["error"] = str(e)
            jobs_col.update_one({"job_id": job_id}, {"$set": {"status": "FAILED", "error": str(e)}})
            await self.broadcast(job_id, {"event": "error", "error": str(e)})

    def _execute_video_pipeline(self, job_id: str):
        job = self.active_jobs[job_id]
        video_path = job["file_path"]
        language = job["language"]

        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise RuntimeError(f"Could not open video file: {video_path}")

        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        duration_sec = total_frames / fps

        # Chunk parameters: window = 2.0 seconds, step = 1.0 second
        window_sec = 2.0
        step_sec = 1.0
        sample_frames = 30

        total_chunks = max(1, int(np.ceil((duration_sec - window_sec) / step_sec)) + 1)
        job["total_chunks"] = total_chunks

        recognized_tokens = []
        partial_results = []

        for chunk_idx in range(total_chunks):
            if job["status"] == "CANCELLED":
                cap.release()
                return

            start_t = chunk_idx * step_sec
            end_t = min(start_t + window_sec, duration_sec)

            # Sample 30 frames uniformly within [start_t, end_t]
            frame_indices = np.linspace(int(start_t * fps), int(end_t * fps) - 1, sample_frames, dtype=int)
            sequence_features = []

            for f_idx in frame_indices:
                cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, f_idx))
                ret, frame = cap.read()
                if not ret or frame is None:
                    sequence_features.append(np.zeros(150, dtype=np.float32))
                    continue

                processed = cv_service.extractor.process_frame(frame)
                sequence_features.append(processed["feature_vector"])

            seq_array = np.array(sequence_features, dtype=np.float32)

            # Check if there was actual motion / gesture (sum of flags)
            has_activity = np.sum(seq_array[:, 126:128]) > 5.0

            if has_activity:
                # Dynamic Bi-LSTM prediction
                pred = cv_service.engine.predict_dynamic(language, seq_array)
                sign = pred["sign"]
                conf = pred["confidence"]

                # Hysteresis deduplication: Don't repeat if matches the very last token
                if conf >= 0.55 and (not recognized_tokens or recognized_tokens[-1] != sign):
                    recognized_tokens.append(sign)
                    partial_item = {
                        "timestamp_sec": round(start_t, 2),
                        "timestamp_str": format_timestamp(start_t),
                        "sign": sign,
                        "confidence": round(conf, 3)
                    }
                    partial_results.append(partial_item)

            # Update Progress
            progress = int(((chunk_idx + 1) / total_chunks) * 90) + 5
            job["progress"] = min(progress, 95)
            job["current_chunk"] = chunk_idx + 1
            job["partial_results"] = partial_results
            job["preliminary_sentence"] = self.sentence_svc.synthesize_sentence(recognized_tokens, language=language)

            jobs_col.update_one(
                {"job_id": job_id},
                {"$set": {
                    "progress": job["progress"],
                    "current_chunk": job["current_chunk"],
                    "partial_results": partial_results,
                    "preliminary_sentence": job["preliminary_sentence"]
                }}
            )

        cap.release()

        # Final transcript synthesis
        final_sentence = self.sentence_svc.synthesize_sentence(recognized_tokens, language=language)
        if not final_sentence and not recognized_tokens:
            final_sentence = "No clear sign language gestures were recognized in this video clip."

        # Generate Subtitle / SRT Content
        srt_lines = []
        for i, item in enumerate(partial_results, 1):
            t_start = item["timestamp_sec"]
            t_end = min(t_start + 1.8, duration_sec)
            sign_text = item["sign"].replace("_", " ")
            srt_lines.append(f"{i}\n{format_srt_time(t_start)} --> {format_srt_time(t_end)}\n{sign_text}\n")

        srt_content = "\n".join(srt_lines)
        srt_filename = f"{job_id}.srt"
        txt_filename = f"{job_id}.txt"

        srt_path = os.path.join(TRANSCRIPT_DIR, srt_filename)
        txt_path = os.path.join(TRANSCRIPT_DIR, txt_filename)

        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)

        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(f"SignBridge AI - Video Translation Transcript\n")
            f.write(f"Language: {language}\nDate: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Duration: {duration_sec:.2f}s\n")
            f.write(f"Translated Sentence: {final_sentence}\n\nDetailed Signs:\n")
            for item in partial_results:
                f.write(f"[{item['timestamp_str']}] {item['sign']} (Confidence: {item['confidence']*100:.1f}%)\n")

        final_transcript = {
            "sentence": final_sentence,
            "tokens_count": len(recognized_tokens),
            "duration_sec": round(duration_sec, 2),
            "srt_download_url": f"/api/jobs/{job_id}/download?format=srt",
            "txt_download_url": f"/api/jobs/{job_id}/download?format=txt",
            "detailed_signs": partial_results
        }

        job["status"] = "COMPLETED"
        job["progress"] = 100
        job["final_transcript"] = final_transcript

        jobs_col.update_one(
            {"job_id": job_id},
            {"$set": {
                "status": "COMPLETED",
                "progress": 100,
                "final_transcript": final_transcript
            }}
        )

        # Record in Translation History
        avg_conf = float(np.mean([p["confidence"] for p in partial_results])) if partial_results else 0.8
        history_col.insert_one({
            "user_id": job.get("user_id"),
            "language": language,
            "input_type": "VIDEO",
            "recognized_signs": recognized_tokens,
            "translated_text": final_sentence,
            "confidence_avg": round(avg_conf, 3),
            "filename": job["filename"],
            "timestamp": datetime.now().isoformat()
        })


video_job_manager = VideoJobManager()
