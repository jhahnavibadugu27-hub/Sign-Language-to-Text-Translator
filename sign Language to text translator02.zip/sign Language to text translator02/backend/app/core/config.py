"""
SignBridge AI - Global Configuration & Environment Settings
"""

import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))

SECRET_KEY = os.getenv("SECRET_KEY", "signbridge_ai_super_secret_jwt_key_2026_evaluator_demo")
ALGORITHM = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))

UPLOAD_DIR = os.path.join(BASE_DIR, "storage", "uploads")
TEMP_DIR = os.path.join(BASE_DIR, "storage", "temporary")
TRANSCRIPT_DIR = os.path.join(BASE_DIR, "storage", "transcripts")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)
os.makedirs(TRANSCRIPT_DIR, exist_ok=True)

STATIC_CONFIDENCE_THRESHOLD = float(os.getenv("STATIC_CONFIDENCE_THRESHOLD", "0.60"))
DYNAMIC_CONFIDENCE_THRESHOLD = float(os.getenv("DYNAMIC_CONFIDENCE_THRESHOLD", "0.65"))
EMERGENCY_CONFIDENCE_THRESHOLD = float(os.getenv("EMERGENCY_CONFIDENCE_THRESHOLD", "0.75"))
