"""
SignBridge AI - Translation Schemas
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional


class ImageTranslationResponse(BaseModel):
    success: bool
    sign: str
    confidence: float
    sentence: str
    language: str
    is_emergency: bool
    probabilities: Dict[str, float]
    hands_detected: int
    annotated_image: Optional[str] = None  # Base64 encoded JPEG overlay
    landmarks: Optional[Dict[str, Any]] = None
    processing_time_ms: float


class EmergencyAlertRequest(BaseModel):
    message: str = Field(..., min_length=2)
    language: str = "ISL"
    manual_override: bool = False
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class EmergencyAlertResponse(BaseModel):
    success: bool
    alert_id: str
    message: str
    spoken_phrase: str
    timestamp: str
    contact_action: str
