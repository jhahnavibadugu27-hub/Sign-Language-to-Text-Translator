"""
SignBridge AI - Video Background Job Schemas
"""

from pydantic import BaseModel
from typing import List, Dict, Any, Optional


class JobInitiateResponse(BaseModel):
    job_id: str
    status: str
    filename: str
    language: str
    message: str


class PartialSignResult(BaseModel):
    timestamp_sec: float
    timestamp_str: str
    sign: str
    confidence: float


class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    progress: int
    language: str
    filename: str
    current_chunk: int
    total_chunks: int
    partial_results: List[PartialSignResult]
    preliminary_sentence: str
    final_transcript: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
