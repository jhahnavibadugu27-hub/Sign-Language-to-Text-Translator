"""
SignBridge AI - FastAPI Application Factory & Main Entrypoint
Mounts REST APIs, WebSocket live streams, and static frontend assets.
"""

import os
import sys

# Ensure root workspace directory is in sys.path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.app.database.connection import db_manager
from backend.app.routes.auth import router as auth_router
from backend.app.routes.translation import router as translation_router
from backend.app.routes.jobs import router as jobs_router
from backend.app.routes.history import router as history_router
from backend.app.routes.dashboard import router as dashboard_router
from backend.app.routes.websocket import router as websocket_router

app = FastAPI(
    title="SignBridge AI",
    description="Advanced Multimodal Indian & American Sign Language Translation Platform",
    version="1.0.0"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Routers
app.include_router(auth_router)
app.include_router(translation_router)
app.include_router(jobs_router)
app.include_router(history_router)
app.include_router(dashboard_router)
app.include_router(websocket_router)


@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "SignBridge AI",
        "database": "connected (live)" if db_manager.is_connected else "in-memory (resilient demo mode)",
        "version": "1.0.0"
    }


# Mount Frontend as Static Directory so the full website can be browsed at http://localhost:8000/
FRONTEND_DIR = os.path.join(ROOT_DIR, "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="127.0.0.1", port=8000, reload=True)
