"""
SignBridge AI - Background Video Job Routes
Polling, SSE streaming, cancellation, and transcript file downloads.
"""

import os
import json
import asyncio
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse, FileResponse

from backend.app.core.config import TRANSCRIPT_DIR
from backend.app.schemas.jobs import JobStatusResponse
from backend.app.services.video_job_service import video_job_manager

router = APIRouter(prefix="/api/jobs", tags=["Video Jobs"])


@router.get("/{job_id}", response_model=JobStatusResponse)
async def get_job_status(job_id: str):
    job = video_job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    return JobStatusResponse(
        job_id=job["job_id"],
        status=job["status"],
        progress=job.get("progress", 0),
        language=job.get("language", "ISL"),
        filename=job.get("filename", ""),
        current_chunk=job.get("current_chunk", 0),
        total_chunks=job.get("total_chunks", 1),
        partial_results=job.get("partial_results", []),
        preliminary_sentence=job.get("preliminary_sentence", ""),
        final_transcript=job.get("final_transcript"),
        error=job.get("error")
    )


@router.get("/{job_id}/stream")
async def stream_job_updates(job_id: str):
    """Server-Sent Events (SSE) delivering live progress and partial signs."""
    job = video_job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    async def event_generator():
        last_progress = -1
        last_count = 0

        while True:
            cur_job = video_job_manager.get_job(job_id)
            if not cur_job:
                break

            status = cur_job.get("status")
            progress = cur_job.get("progress", 0)
            partials = cur_job.get("partial_results", [])

            # Emit update when progress changes or new partial results arrive
            if progress != last_progress or len(partials) != last_count or status in ["COMPLETED", "FAILED", "CANCELLED"]:
                last_progress = progress
                last_count = len(partials)
                payload = {
                    "job_id": job_id,
                    "status": status,
                    "progress": progress,
                    "current_chunk": cur_job.get("current_chunk", 0),
                    "total_chunks": cur_job.get("total_chunks", 1),
                    "partial_results": partials,
                    "preliminary_sentence": cur_job.get("preliminary_sentence", ""),
                    "final_transcript": cur_job.get("final_transcript")
                }
                yield f"data: {json.dumps(payload)}\n\n"

            if status in ["COMPLETED", "FAILED", "CANCELLED"]:
                break

            await asyncio.sleep(0.5)

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@router.post("/{job_id}/cancel")
async def cancel_job(job_id: str):
    success = video_job_manager.cancel_job(job_id)
    if not success:
        raise HTTPException(status_code=404, detail="Job not found or could not be cancelled.")
    return {"message": "Job successfully cancelled.", "job_id": job_id}


@router.get("/{job_id}/download")
async def download_transcript(job_id: str, format: str = Query("txt", pattern="^(txt|srt)$")):
    filename = f"{job_id}.{format}"
    filepath = os.path.join(TRANSCRIPT_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail=f"Transcript file {filename} not found.")

    media_type = "text/plain" if format == "txt" else "application/x-subrip"
    return FileResponse(filepath, media_type=media_type, filename=filename)
