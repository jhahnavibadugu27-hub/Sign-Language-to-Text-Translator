"""
SignBridge AI - Authentication Routes
Registration, Login, and Current User profile endpoints.
"""

from fastapi import APIRouter, HTTPException, status, Depends
from datetime import datetime

from backend.app.schemas.auth import (
    UserRegisterSchema,
    UserLoginSchema,
    UserResponseSchema,
    TokenResponseSchema
)
from backend.app.database.collections import users_col
from backend.app.core.security import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user
)

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/register", response_model=TokenResponseSchema)
async def register(payload: UserRegisterSchema):
    # Check duplicate email
    existing = users_col.find_one({"email": payload.email.lower()})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email address already exists."
        )

    pwd_hash = hash_password(payload.password)
    user_doc = {
        "full_name": payload.full_name,
        "email": payload.email.lower(),
        "password_hash": pwd_hash,
        "preferred_language": payload.preferred_language or "ISL",
        "created_at": datetime.now().isoformat()
    }
    res = users_col.insert_one(user_doc)
    user_id = str(res.inserted_id)

    token = create_access_token({"sub": payload.email.lower(), "user_id": user_id})

    user_resp = UserResponseSchema(
        id=user_id,
        full_name=payload.full_name,
        email=payload.email.lower(),
        preferred_language=payload.preferred_language or "ISL",
        created_at=user_doc["created_at"]
    )

    return TokenResponseSchema(access_token=token, user=user_resp)


@router.post("/login", response_model=TokenResponseSchema)
async def login(payload: UserLoginSchema):
    user = users_col.find_one({"email": payload.email.lower()})
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password."
        )

    user_id = str(user.get("_id", "1"))
    token = create_access_token({"sub": user["email"], "user_id": user_id})

    user_resp = UserResponseSchema(
        id=user_id,
        full_name=user["full_name"],
        email=user["email"],
        preferred_language=user.get("preferred_language", "ISL"),
        created_at=user.get("created_at")
    )

    return TokenResponseSchema(access_token=token, user=user_resp)


@router.get("/me", response_model=UserResponseSchema)
async def get_profile(current_user: dict = Depends(get_current_user)):
    return UserResponseSchema(
        id=str(current_user.get("_id", "1")),
        full_name=current_user["full_name"],
        email=current_user["email"],
        preferred_language=current_user.get("preferred_language", "ISL"),
        created_at=current_user.get("created_at")
    )
