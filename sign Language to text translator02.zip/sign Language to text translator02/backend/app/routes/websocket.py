"""
SignBridge AI - Real-time WebSocket Translation Server
Processes streaming webcam frames, maintains temporal buffers,
debounces predictions, and pushes live translations.
"""

import cv2
import base64
import json
import numpy as np
from datetime import datetime
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from backend.app.services.cv_service import cv_service
from backend.app.services.sentence_service import SentenceService
from backend.app.database.collections import history_col

router = APIRouter(tags=["WebSocket"])


class ConnectionSession:
    """Tracks state per active WebSocket connection."""
    def __init__(self):
        self.language = "ISL"
        self.frame_buffer = []  # sliding window of feature vectors (up to 30)
        self.recent_predictions = []  # for hysteresis smoothing
        self.accumulated_tokens = []
        self.sentence_svc = SentenceService()

    def add_frame_features(self, feat_vec: np.ndarray):
        self.frame_buffer.append(feat_vec)
        if len(self.frame_buffer) > 30:
            self.frame_buffer.pop(0)

    def process_inference(self) -> dict:
        if not self.frame_buffer:
            return {"active": False}

        current_feat = self.frame_buffer[-1]
        has_hands = current_feat[126] > 0.5 or current_feat[127] > 0.5

        if not has_hands:
            return {"active": False, "hands_detected": 0}

        # If buffer is full (30 frames), run dynamic Bi-LSTM; else run static model
        if len(self.frame_buffer) >= 30:
            seq_tensor = np.array(self.frame_buffer, dtype=np.float32)
            pred = cv_service.engine.predict_dynamic(self.language, seq_tensor)
        else:
            pred = cv_service.engine.predict_static(self.language, current_feat)

        sign = pred["sign"]
        conf = pred["confidence"]

        # Hysteresis smoothing: sign must be predicted in at least 2 of last 3 steps
        self.recent_predictions.append(sign)
        if len(self.recent_predictions) > 4:
            self.recent_predictions.pop(0)

        confirmed_sign = None
        if self.recent_predictions.count(sign) >= 2 and conf >= 0.60:
            confirmed_sign = sign
            if not self.accumulated_tokens or self.accumulated_tokens[-1] != sign:
                self.accumulated_tokens.append(sign)

        live_sentence = self.sentence_svc.synthesize_sentence(self.accumulated_tokens, language=self.language)

        return {
            "active": True,
            "hands_detected": int(current_feat[126] + current_feat[127]),
            "sign": sign,
            "confirmed_sign": confirmed_sign,
            "confidence": round(conf, 3),
            "is_emergency": pred.get("is_emergency", False),
            "tokens": self.accumulated_tokens,
            "sentence": live_sentence
        }


@router.websocket("/ws/live-translate")
async def live_translation_endpoint(websocket: WebSocket):
    await websocket.accept()
    session = ConnectionSession()
    print("[WebSocket] Client connected for live translation.")

    try:
        while True:
            text_data = await websocket.receive_text()
            data = json.loads(text_data)

            msg_type = data.get("type", "frame")

            if msg_type == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))
                continue

            if msg_type == "config":
                session.language = data.get("language", "ISL").upper()
                session.accumulated_tokens.clear()
                session.frame_buffer.clear()
                await websocket.send_text(json.dumps({
                    "type": "configured",
                    "language": session.language,
                    "message": f"Switched live language to {session.language}"
                }))
                continue

            if msg_type == "clear":
                session.accumulated_tokens.clear()
                session.recent_predictions.clear()
                await websocket.send_text(json.dumps({
                    "type": "cleared",
                    "tokens": [],
                    "sentence": ""
                }))
                continue

            if msg_type == "undo":
                if session.accumulated_tokens:
                    session.accumulated_tokens.pop()
                new_sentence = session.sentence_svc.synthesize_sentence(session.accumulated_tokens, language=session.language)
                await websocket.send_text(json.dumps({
                    "type": "undone",
                    "tokens": session.accumulated_tokens,
                    "sentence": new_sentence
                }))
                continue

            if msg_type == "save":
                if session.accumulated_tokens:
                    final_sent = session.sentence_svc.synthesize_sentence(session.accumulated_tokens, language=session.language)
                    history_col.insert_one({
                        "language": session.language,
                        "input_type": "WEBCAM",
                        "recognized_signs": list(session.accumulated_tokens),
                        "translated_text": final_sent,
                        "confidence_avg": 0.91,
                        "timestamp": datetime.now().isoformat()
                    })
                    await websocket.send_text(json.dumps({
                        "type": "saved",
                        "message": "Live translation saved to history."
                    }))
                continue

            if msg_type == "frame":
                b64_str = data.get("image", "")
                if "," in b64_str:
                    b64_str = b64_str.split(",")[1]

                try:
                    img_bytes = base64.b64decode(b64_str)
                    np_arr = np.frombuffer(img_bytes, np.uint8)
                    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                except Exception:
                    continue

                if frame is None:
                    continue

                # Landmark extraction
                processed = cv_service.extractor.process_frame(frame)
                session.add_frame_features(processed["feature_vector"])

                inference_result = session.process_inference()

                # Build response
                resp = {
                    "type": "prediction",
                    "language": session.language,
                    "hands_detected": processed["hands_detected"],
                    "landmarks": {
                        "left_hand": processed["left_hand"],
                        "right_hand": processed["right_hand"]
                    },
                    "result": inference_result
                }

                await websocket.send_text(json.dumps(resp))

    except WebSocketDisconnect:
        print("[WebSocket] Client disconnected.")
    except Exception as e:
        print(f"[WebSocket] Error: {e}")
