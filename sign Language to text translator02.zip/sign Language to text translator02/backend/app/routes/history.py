"""
SignBridge AI - Translation History Routes
Paginated records, search, language filtering, and deletion.
"""

from fastapi import APIRouter, Query, HTTPException, Depends
from typing import Optional
from backend.app.database.collections import history_col
from backend.app.core.security import get_current_user_optional

router = APIRouter(prefix="/api/history", tags=["History"])


@router.get("")
async def get_history(
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    language: Optional[str] = None,
    input_type: Optional[str] = None,
    search: Optional[str] = None,
    current_user: Optional[dict] = Depends(get_current_user_optional)
):
    query = {}
    if current_user:
        query["user_id"] = str(current_user["_id"])
    if language and language.upper() in ["ISL", "ASL"]:
        query["language"] = language.upper()
    if input_type:
        query["input_type"] = input_type.upper()

    all_docs = history_col.find(query, sort=[("timestamp", -1)])

    # Search filter across translated text or recognized signs
    if search:
        search_lower = search.lower()
        all_docs = [
            doc for doc in all_docs
            if search_lower in doc.get("translated_text", "").lower()
            or any(search_lower in str(s).lower() for s in doc.get("recognized_signs", []))
        ]

    total = len(all_docs)
    skip = (page - 1) * limit
    paginated = all_docs[skip:skip + limit]

    # Convert ObjectId to string
    for item in paginated:
        item["id"] = str(item.get("_id", item.get("id", "")))

    return {
        "page": page,
        "limit": limit,
        "total": total,
        "total_pages": max(1, (total + limit - 1) // limit),
        "items": paginated
    }


@router.get("/{record_id}")
async def get_history_detail(record_id: str):
    doc = history_col.find_one({"_id": record_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Translation record not found.")
    doc["id"] = str(doc.get("_id", record_id))
    return doc


@router.delete("/{record_id}")
async def delete_history_record(record_id: str):
    history_col.delete_one({"_id": record_id})
    return {"message": "Record deleted successfully.", "id": record_id}
