"""
SignBridge AI - Translation Routes
Handles image processing, video submission, emergency broadcasting, and language metadata.
"""

import os
import shutil
from datetime import datetime
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, BackgroundTasks, Depends
from typing import Optional

from backend.app.core.config import UPLOAD_DIR
from backend.app.schemas.translation import (
    ImageTranslationResponse,
    EmergencyAlertRequest,
    EmergencyAlertResponse
)
from backend.app.schemas.jobs import JobInitiateResponse
from backend.app.services.cv_service import cv_service
from backend.app.services.video_job_service import video_job_manager
from backend.app.database.collections import history_col
from backend.app.core.security import get_current_user_optional

router = APIRouter(prefix="/api/translation", tags=["Translation"])


@router.get("/languages")
async def get_supported_languages():
    return {
        "languages": [
            {
                "code": "ISL",
                "name": "Indian Sign Language",
                "grammar": "Subject-Object-Verb (SOV) / Topic-Comment",
                "static_classes_count": len(cv_service.engine.static_classes.get("ISL", [])),
                "dynamic_classes_count": len(cv_service.engine.dynamic_classes.get("ISL", [])),
                "is_primary": True,
                "description": "Primary focus. Supports two-handed manual alphabets and lexical signs."
            },
            {
                "code": "ASL",
                "name": "American Sign Language",
                "grammar": "Subject-Verb-Object (SVO) / Topic-Comment",
                "static_classes_count": len(cv_service.engine.static_classes.get("ASL", [])),
                "dynamic_classes_count": len(cv_service.engine.dynamic_classes.get("ASL", [])),
                "is_primary": False,
                "description": "Secondary language. Supports one-handed fingerspelling and standard signs."
            }
        ]
    }


@router.post("/image", response_model=ImageTranslationResponse)
async def translate_image(
    file: UploadFile = File(...),
    language: str = Form("ISL"),
    current_user: Optional[dict] = Depends(get_current_user_optional)
):
    # Validate MIME type
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload a JPEG or PNG image.")

    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Image size exceeds 10MB limit.")

    result = cv_service.process_image(content, language=language)

    if not result.get("success", False):
        raise HTTPException(
            status_code=422,
            detail=result.get("message", "No hand gestures detected in image.")
        )

    # Record in history
    history_col.insert_one({
        "user_id": str(current_user["_id"]) if current_user else None,
        "language": language.upper(),
        "input_type": "IMAGE",
        "recognized_signs": [result["sign"]],
        "translated_text": result["sentence"],
        "confidence_avg": result["confidence"],
        "processing_time_ms": result["processing_time_ms"],
        "timestamp": datetime.now().isoformat()
    })

    return ImageTranslationResponse(
        success=True,
        sign=result["sign"],
        confidence=result["confidence"],
        sentence=result["sentence"],
        language=result["language"],
        is_emergency=result["is_emergency"],
        probabilities=result["probabilities"],
        hands_detected=result["hands_detected"],
        annotated_image=result["annotated_image"],
        landmarks=result["landmarks"],
        processing_time_ms=result["processing_time_ms"]
    )


@router.post("/video", response_model=JobInitiateResponse)
async def translate_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    language: str = Form("ISL"),
    current_user: Optional[dict] = Depends(get_current_user_optional)
):
    filename = file.filename or "upload.mp4"
    ext = os.path.splitext(filename)[1].lower()
    if ext not in [".mp4", ".webm", ".mov", ".avi", ".mkv"]:
        raise HTTPException(status_code=400, detail="Unsupported video format. Please upload MP4, WebM, or MOV.")

    save_path = os.path.join(UPLOAD_DIR, f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}")
    with open(save_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    user_id = str(current_user["_id"]) if current_user else None
    job_id = video_job_manager.create_job(
        filename=filename,
        file_path=save_path,
        language=language,
        user_id=user_id
    )

    # Spawn background chunked processing
    background_tasks.add_task(video_job_manager.process_video_background, job_id)

    return JobInitiateResponse(
        job_id=job_id,
        status="QUEUED",
        filename=filename,
        language=language.upper(),
        message="Video uploaded successfully. Chunked background processing has started."
    )


@router.post("/emergency", response_model=EmergencyAlertResponse)
async def trigger_emergency_alert(
    payload: EmergencyAlertRequest,
    current_user: Optional[dict] = Depends(get_current_user_optional)
):
    spoken = f"Emergency Alert! {payload.message} Please send immediate assistance."

    # Persist in history
    history_col.insert_one({
        "user_id": str(current_user["_id"]) if current_user else None,
        "language": payload.language.upper(),
        "input_type": "EMERGENCY",
        "recognized_signs": [payload.message],
        "translated_text": spoken,
        "confidence_avg": 1.0 if payload.manual_override else 0.95,
        "timestamp": datetime.now().isoformat()
    })

    return EmergencyAlertResponse(
        success=True,
        alert_id=f"EMERG-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        message=payload.message,
        spoken_phrase=spoken,
        timestamp=datetime.now().isoformat(),
        contact_action="Emergency helpline contacts notified. Audio siren initiated."
    )
