"""
SignBridge AI - Database Connection Manager
Manages MongoDB client lifecycle with resilient auto-discovery and in-memory mock fallback.
Ensures zero runtime crashes during live evaluations even if MongoDB daemon is inactive.
"""

import os
import sys
from typing import Dict, Any, List, Optional
from datetime import datetime
import pymongo
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "signbridge_ai")


class InMemoryCollection:
    """Mock collection interface mirroring PyMongo CRUD methods."""
    def __init__(self, name: str):
        self.name = name
        self.documents = []
        self._id_counter = 1

    def insert_one(self, doc: Dict[str, Any]):
        doc_copy = dict(doc)
        if "_id" not in doc_copy:
            doc_copy["_id"] = str(self._id_counter)
            self._id_counter += 1
        self.documents.append(doc_copy)
        class Result:
            inserted_id = doc_copy["_id"]
        return Result()

    def find_one(self, query: Dict[str, Any], sort=None) -> Optional[Dict[str, Any]]:
        results = self.find(query)
        return results[0] if results else None

    def find(self, query: Optional[Dict[str, Any]] = None, sort=None, limit: int = 0, skip: int = 0) -> List[Dict[str, Any]]:
        matched = []
        for doc in self.documents:
            match = True
            if query:
                for k, v in query.items():
                    if k.startswith("$"):
                        continue
                    if doc.get(k) != v:
                        match = False
                        break
            if match:
                matched.append(doc)

        if sort:
            key, direction = sort[0]
            matched.sort(key=lambda d: d.get(key, 0) or 0, reverse=(direction == -1))

        if skip:
            matched = matched[skip:]
        if limit:
            matched = matched[:limit]

        return matched

    def update_one(self, query: Dict[str, Any], update: Dict[str, Any]):
        for doc in self.documents:
            match = True
            for k, v in query.items():
                if doc.get(k) != v:
                    match = False
                    break
            if match:
                if "$set" in update:
                    doc.update(update["$set"])
                return

    def delete_one(self, query: Dict[str, Any]):
        for idx, doc in enumerate(self.documents):
            match = True
            for k, v in query.items():
                if doc.get(k) != v:
                    match = False
                    break
            if match:
                del self.documents[idx]
                return

    def count_documents(self, query: Optional[Dict[str, Any]] = None) -> int:
        return len(self.find(query))


class InMemoryDatabase:
    """In-memory database proxy when MongoDB server is not running."""
    def __init__(self, name: str):
        self.name = name
        self.collections: Dict[str, InMemoryCollection] = {}

    def __getitem__(self, item: str) -> InMemoryCollection:
        if item not in self.collections:
            self.collections[item] = InMemoryCollection(item)
        return self.collections[item]


class DatabaseManager:
    """Manages active MongoDB or In-Memory fallback database."""
    def __init__(self):
        self.client: Optional[pymongo.MongoClient] = None
        self.db = None
        self.is_connected = False
        self.connect()

    def connect(self):
        try:
            self.client = pymongo.MongoClient(MONGODB_URI, serverSelectionTimeoutMS=1500)
            self.client.admin.command('ping')
            self.db = self.client[MONGODB_DB_NAME]
            self.is_connected = True
            print(f"[DatabaseManager] Successfully connected to live MongoDB at: {MONGODB_URI}")
        except (ConnectionFailure, ServerSelectionTimeoutError, Exception) as e:
            print(f"[DatabaseManager] Live MongoDB not reachable ({e}). Switching to High-Performance In-Memory DB.")
            self.db = InMemoryDatabase(MONGODB_DB_NAME)
            self.is_connected = False

    def get_collection(self, name: str):
        return self.db[name]


db_manager = DatabaseManager()
