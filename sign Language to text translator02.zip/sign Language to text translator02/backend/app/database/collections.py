"""
SignBridge AI - Database Collections & Indices
Defines standard collections for users, jobs, history, sessions, and preferences.
"""

from backend.app.database.connection import db_manager

users_col = db_manager.get_collection("users")
history_col = db_manager.get_collection("translation_history")
jobs_col = db_manager.get_collection("translation_jobs")
sessions_col = db_manager.get_collection("translation_sessions")
preferences_col = db_manager.get_collection("user_preferences")
