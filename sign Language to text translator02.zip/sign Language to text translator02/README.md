# SignBridge AI – Advanced Multimodal ISL & ASL to Text and Speech Translator

[![Python Version](https://img.shields.io/badge/Python-3.14%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/Backend-FastAPI-009688.svg)](https://fastapi.tiangolo.com/)
[![MediaPipe Tasks](https://img.shields.io/badge/CV-Google%20MediaPipe-orange.svg)](https://developers.google.com/mediapipe)
[![PyTorch](https://img.shields.io/badge/Deep%20Learning-PyTorch%20Bi--LSTM-red.svg)](https://pytorch.org/)
[![MongoDB](https://img.shields.io/badge/Database-MongoDB%20%2F%20In--Memory-green.svg)](https://www.mongodb.com/)
[![Tests Status](https://img.shields.io/badge/Tests-14%20Passed%20(100%25)-brightgreen.svg)]()

---

## 1. Executive Summary
**SignBridge AI** is an advanced, multimodal accessibility communication platform engineered to bridge communication barriers between the Deaf and Hard of Hearing (DHH) community and the hearing populace.

Unlike simplistic toy prototypes that merely classify static single-hand 2D fingerspelling, SignBridge AI provides **independent bilingual recognition pipelines** for:
- **Indian Sign Language (ISL)** – Primary focus. Incorporates two-handed alphabets, SOV grammar syntax, and authentic ISLRTC lexical signs.
- **American Sign Language (ASL)** – Secondary focus. Incorporates one-handed fingerspelling, SVO grammar syntax, and WLASL lexical gestures.

---

## 2. Key Capabilities & Features

### 📷 1. High-Resolution Static Image Studio
- Accepts JPEG, JPG, and PNG uploads up to 10MB.
- Extracts 21 keypoints per hand + 7 upper-body torso landmarks using Google MediaPipe Tasks.
- Performs wrist-centered translation and palm-span scale normalization.
- Generates real-time visual skeleton overlays, top class probabilities, and synthesized speech playback.

### 🎬 2. Continuous Lengthy Video Translation (Sliding-Window Chunks)
- Memory-safe chunked video processing (2.0s window with 0.5s step).
- 15 fps uniform frame sampling.
- PyTorch Bidirectional LSTM (`Bi-LSTM`) sequence model with temporal attention.
- Streams preliminary recognized signs to the frontend via Server-Sent Events (SSE) before the entire video finishes.
- Synthesizes readable continuous sentences and generates downloadable transcripts (`.TXT` and `.SRT` subtitle format).

### 🎥 3. Real-Time Live Webcam Translation (Sub-50ms Latency)
- Direct browser camera capture using `MediaDevices.getUserMedia()`.
- Lightweight offscreen canvas downsampling transmitted via bidirectional WebSocket (`/ws/live-translate`).
- Real-time HTML5 Canvas skeleton overlay mirroring the user's hand movements.
- Temporal hysteresis debouncing (gesture must persist across $\ge 2$ consecutive inferences with confidence $\ge 0.60$) to eliminate gesture flicker.
- Speech playback, Undo Last Sign, Clear Text, and Save Translation to MongoDB.

### 🚨 4. Priority Emergency HUD
- High-contrast, accessibility-first interface designed for critical situations (medical, ambulance, police, fire, injury).
- Instant speech broadcast at maximum volume with one-click dispatch.
- Quick direct dialing pills for national emergency helplines (112, 108, 100, 911).

### 📊 5. Telemetry Dashboard & History
- Real-time analytics tracking total translations, video jobs, and modality usage.
- Native HTML5 Canvas charts (no heavy external chart libraries).
- Verified empirical model benchmark displays.
- Searchable and filterable history table with CSV export.

---

## 3. Technology Stack

- **Frontend**: Semantic HTML5, CSS3 with a unified SaaS design system, Vanilla JavaScript (ES6+), Fetch API, WebSocket API, Web SpeechSynthesis API.
- **Backend**: Python 3.14+, FastAPI, Starlette WebSockets, Pydantic v2, PyJWT, Bcrypt.
- **Computer Vision & AI/ML**: OpenCV, Google MediaPipe Tasks (`hand_landmarker.task`, `pose_landmarker.task`), Scikit-Learn (Random Forest 120 estimators), PyTorch 2.x (2-layer Bidirectional LSTM with Temporal Attention).
- **Database**: MongoDB with PyMongo driver, accompanied by a resilient In-Memory fallback database ensuring zero crashes if the MongoDB service is offline during evaluations.

---

## 4. Project Directory Structure

```text
SignBridge-AI/
├── frontend/                     # 10 Responsive HTML5/CSS3/Vanilla JS Pages
│   ├── index.html                # Product landing page & modality showcase
│   ├── image-translator.html     # Image upload, landmark overlay & probabilities
│   ├── video-translator.html     # Chunked video upload, live transcript & SRT export
│   ├── live-translator.html      # Real-time WebSocket camera translation
│   ├── emergency.html            # High-visibility emergency dispatch HUD
│   ├── dashboard.html            # Analytics, telemetry & canvas charts
│   ├── history.html              # Searchable database logs & CSV export
│   ├── login.html                # JWT User sign-in
│   ├── register.html             # User registration
│   ├── about.html                # Project report & engineering credentials
│   ├── css/                      # Modular CSS3 stylesheets
│   └── js/                       # Modular ES6+ JavaScript controllers
├── backend/                      # Python FastAPI Architecture
│   ├── app/
│   │   ├── main.py               # Main entry point & static asset mounting
│   │   ├── core/                 # Config, secrets & bcrypt security
│   │   ├── database/             # MongoDB manager & in-memory fallback
│   │   ├── schemas/              # Pydantic v2 request/response schemas
│   │   ├── routes/               # REST routers & WebSocket live streams
│   │   └── services/             # CV, Video Chunking, and Sentence services
│   └── requirements.txt
├── ai_engine/                    # Dual Bilingual AI/ML Engine
│   ├── datasets/                 # ISL & ASL vocabulary configurations
│   ├── preprocessing/            # MediaPipe Tasks & 150-dim coordinate normalizer
│   ├── training/                 # Static Random Forest & PyTorch Bi-LSTM training
│   ├── saved_models/             # Serialized .joblib and PyTorch .pt weights
│   └── evaluation/               # Model evaluation reports & confusion matrices
├── storage/                      # File storage staging areas
│   ├── uploads/                  # Uploaded video and image files
│   ├── temporary/                # Video chunk decimation frames
│   └── transcripts/              # Generated TXT & SRT files
├── tests/                        # Full Pytest Test Suite (14 Passed)
└── docs/                         # Architecture, API & Viva documentation
```

---

## 5. Quickstart & Installation

### Step 1: Clone or Navigate to Directory
```powershell
cd "c:\2ndyear1stsem\sign Language to text translator02"
```

### Step 2: Install Dependencies
```powershell
pip install -r backend/requirements.txt
```

### Step 3: Run the Application Server
```powershell
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```

### Step 4: Access the Application
Open your web browser and navigate to:
```
http://127.0.0.1:8000/
```
The FastAPI backend serves both the complete REST API / WebSockets and the responsive frontend assets.

---

## 6. Running Tests
To verify all 14 unit and integration tests:
```powershell
python -m pytest tests -v
```

---

## 7. Two-Member Team Division

| Member | Primary Role | Core Modules |
| :--- | :--- | :--- |
| **Member 1** | Python Backend, Computer Vision & AI/ML | OpenCV & MediaPipe pipeline, 150-dim feature normalizer, PyTorch Bi-LSTM models, sliding-window chunk video worker, FastAPI REST & WebSocket routes. |
| **Member 2** | Frontend Engineering, UI/UX & System Integration | 10 Responsive HTML5/CSS3 SaaS pages, camera capture loop, HTML5 Canvas skeleton overlays, Web SpeechSynthesis engine, Emergency HUD, Dashboard analytics. |
