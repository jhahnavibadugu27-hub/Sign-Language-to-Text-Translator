"""
SignBridge AI - Anatomical Gesture Dataset Generator
Generates realistic 3D landmark keypoint distributions for ISL and ASL static and dynamic vocabulary.
Based on anatomical finger flexion, abduction, and upper-body orientation standards.
"""

import os
import json
import numpy as np
from typing import Dict, List, Tuple

# Base anatomical neutral hand pose (wrist at 0, 0, 0)
# 21 landmarks: 0: Wrist, 1-4: Thumb, 5-8: Index, 9-12: Middle, 13-16: Ring, 17-20: Pinky
BASE_HAND_REST = np.array([
    [0.0, 0.0, 0.0],       # 0: Wrist
    [-0.2, -0.15, -0.05],  # 1: Thumb CMC
    [-0.35, -0.3, -0.08],  # 2: Thumb MCP
    [-0.45, -0.42, -0.1],  # 3: Thumb IP
    [-0.52, -0.55, -0.12], # 4: Thumb TIP
    [-0.15, -0.5, 0.0],    # 5: Index MCP
    [-0.16, -0.7, 0.0],    # 6: Index PIP
    [-0.17, -0.85, 0.0],   # 7: Index DIP
    [-0.18, -1.0, 0.0],    # 8: Index TIP
    [0.0, -0.52, 0.0],     # 9: Middle MCP
    [0.0, -0.74, 0.0],     # 10: Middle PIP
    [0.0, -0.9, 0.0],      # 11: Middle DIP
    [0.0, -1.05, 0.0],     # 12: Middle TIP
    [0.15, -0.48, 0.0],    # 13: Ring MCP
    [0.16, -0.68, 0.0],    # 14: Ring PIP
    [0.17, -0.83, 0.0],    # 15: Ring DIP
    [0.18, -0.96, 0.0],    # 16: Ring TIP
    [0.28, -0.42, 0.0],    # 17: Pinky MCP
    [0.32, -0.58, 0.0],    # 18: Pinky PIP
    [0.34, -0.71, 0.0],    # 19: Pinky DIP
    [0.36, -0.82, 0.0],    # 20: Pinky TIP
], dtype=np.float32)


def get_static_hand_archetype(label: str, is_left: bool = False) -> np.ndarray:
    """Returns archetypal 21x3 coordinates for specific sign postures."""
    pose = BASE_HAND_REST.copy()
    sign = label.upper()

    # Closed fist baseline for 'A', 'HELP' (fist)
    if sign in ['A', 'HELP', 'POLICE']:
        # Curl all fingers down into palm
        for finger_indices in [[5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]]:
            mcp = pose[finger_indices[0]]
            pose[finger_indices[1]] = mcp + [0.0, 0.1, 0.15]
            pose[finger_indices[2]] = mcp + [0.0, 0.2, 0.25]
            pose[finger_indices[3]] = mcp + [0.0, 0.25, 0.15]
        # Thumb resting along index
        pose[4] = pose[5] + [0.05, 0.05, 0.1]

    elif sign in ['B', 'NAMASTE']:
        # All 4 fingers straight up, thumb tucked across palm
        pose[4] = pose[9] + [0.05, 0.2, 0.1]

    elif sign in ['C', 'MEDICAL']:
        # Curved claw/arc
        for finger_indices in [[5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]]:
            pose[finger_indices[2]][2] += 0.3
            pose[finger_indices[3]][2] += 0.45
            pose[finger_indices[3]][1] += 0.2
        pose[4][2] += 0.35

    elif sign in ['D', '1']:
        # Index straight up, other fingers touching thumb tip
        for finger_indices in [[9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]]:
            mcp = pose[finger_indices[0]]
            pose[finger_indices[3]] = mcp + [0.0, 0.2, 0.15]
        pose[4] = pose[9] + [0.0, 0.1, 0.1]

    elif sign in ['L']:
        # Index straight up, thumb pointing 90 degrees outward
        for finger_indices in [[9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]]:
            mcp = pose[finger_indices[0]]
            pose[finger_indices[3]] = mcp + [0.0, 0.2, 0.15]
        pose[4] = [-0.75, -0.05, 0.0]

    elif sign in ['V', '2', 'PEACE']:
        # Index and middle straight up in V, ring and pinky closed
        pose[8] = [-0.25, -1.0, 0.0]
        pose[12] = [0.25, -1.0, 0.0]
        for finger_indices in [[13, 14, 15, 16], [17, 18, 19, 20]]:
            mcp = pose[finger_indices[0]]
            pose[finger_indices[3]] = mcp + [0.0, 0.2, 0.15]
        pose[4] = pose[13] + [0.0, 0.1, 0.1]

    elif sign in ['Y', 'I_LOVE_YOU']:
        # Thumb and pinky extended, middle 3 curled
        pose[4] = [-0.65, -0.3, 0.0]
        pose[20] = [0.55, -0.7, 0.0]
        for finger_indices in [[5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]:
            if sign == 'I_LOVE_YOU' and finger_indices[0] == 5:
                continue  # Index stays up in I_LOVE_YOU
            mcp = pose[finger_indices[0]]
            pose[finger_indices[3]] = mcp + [0.0, 0.2, 0.15]

    elif sign in ['YES']:
        # Fist tilting slightly forward (nodding motion static representation)
        for finger_indices in [[5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16], [17, 18, 19, 20]]:
            mcp = pose[finger_indices[0]]
            pose[finger_indices[3]] = mcp + [0.0, 0.2, 0.15]

    elif sign in ['NO']:
        # Index and middle snap against thumb
        pose[8] = pose[4] + [0.02, 0.02, 0.0]
        pose[12] = pose[4] + [0.05, 0.02, 0.0]
        for finger_indices in [[13, 14, 15, 16], [17, 18, 19, 20]]:
            mcp = pose[finger_indices[0]]
            pose[finger_indices[3]] = mcp + [0.0, 0.2, 0.15]

    if is_left:
        pose[:, 0] *= -1.0  # Mirror x-axis for left hand

    return pose


def generate_static_samples(
    classes: List[str],
    samples_per_class: int = 120,
    language: str = "ISL"
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generates normalized 150-dim feature vectors with realistic anatomical variance:
    - Signer size variability (scale jitter 0.85 - 1.15)
    - Camera angle rotation (-15 to +15 degrees)
    - Sensor noise (Gaussian jitter sigma = 0.02)
    - Multi-hand configuration (ISL incorporates dual-hand interactions like Namaste & Help).
    """
    np.random.seed(42)
    X = []
    y = []

    for class_idx, label in enumerate(classes):
        for _ in range(samples_per_class):
            # Base right hand
            rh = get_static_hand_archetype(label, is_left=False).copy()

            # Random 3D rotation matrix
            theta = np.random.uniform(-0.15, 0.15)
            rot_z = np.array([
                [np.cos(theta), -np.sin(theta), 0],
                [np.sin(theta), np.cos(theta), 0],
                [0, 0, 1]
            ])
            rh = rh @ rot_z.T

            # Scale and noise
            scale = np.random.uniform(0.9, 1.1)
            noise = np.random.normal(0, 0.015, rh.shape)
            rh = (rh * scale) + noise

            # Flatten normalized right hand (63 floats)
            rh_norm = rh.flatten()

            # Left hand handling
            is_two_handed = label in ['NAMASTE', 'HELP', 'MEDICAL', 'POLICE', 'DANGER'] or (language == 'ISL' and label in ['A', 'B', 'C', 'D', 'E'])
            
            if is_two_handed:
                lh = get_static_hand_archetype(label, is_left=True).copy()
                lh = (lh @ rot_z.T) * scale + np.random.normal(0, 0.015, lh.shape)
                lh_norm = lh.flatten()
                has_left = 1.0
            else:
                lh_norm = np.zeros(63, dtype=np.float32)
                has_left = 0.0

            has_right = 1.0

            # Pose features (7 keypoints * 3 = 21 floats)
            # Default upper torso pose with subtle movement
            pose = np.array([
                [0.0, -1.2, 0.0],     # Nose
                [-0.6, -0.8, 0.0],    # Left shoulder
                [0.6, -0.8, 0.0],     # Right shoulder
                [-0.8, -0.3, 0.1],    # Left elbow
                [0.8, -0.3, 0.1],     # Right elbow
                [-0.5, 0.0, 0.2],     # Left wrist
                [0.5, 0.0, 0.2]       # Right wrist
            ], dtype=np.float32)
            pose += np.random.normal(0, 0.02, pose.shape)
            pose_norm = pose.flatten()
            has_pose = 1.0

            # Assemble full 150-dim feature vector
            feat_vec = np.concatenate([
                lh_norm,
                rh_norm,
                np.array([has_left, has_right], dtype=np.float32),
                pose_norm,
                np.array([has_pose], dtype=np.float32)
            ])

            X.append(feat_vec)
            y.append(class_idx)

    return np.array(X, dtype=np.float32), np.array(y, dtype=np.int64)


def generate_dynamic_sequences(
    classes: List[str],
    samples_per_class: int = 80,
    seq_len: int = 30,
    language: str = "ISL"
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generates temporal gesture trajectories (Batch, 30, 150) for dynamic signs:
    - Simulates start posture -> transitional trajectory -> peak gesture -> return.
    """
    np.random.seed(1337)
    X = []
    y = []

    for class_idx, label in enumerate(classes):
        for _ in range(samples_per_class):
            sequence = np.zeros((seq_len, 150), dtype=np.float32)

            # Trajectory phase parameter t from 0 to 1
            t = np.linspace(0, 1, seq_len)

            # Different movement frequency and trajectory signatures per dynamic sign
            if 'HELLO' in label:
                # Oscillating hand wave on right hand x-coordinate
                wave = np.sin(t * 3 * np.pi) * 0.35
                shift_x = wave
                shift_y = -0.2 * np.sin(t * np.pi)
            elif 'THANK_YOU' in label:
                # Movement from chin forward and downward
                shift_x = 0.05 * t
                shift_y = 0.5 * t
            elif 'WATER' in label or 'FOOD' in label:
                # Hand moves towards mouth/chin and taps twice
                shift_x = np.zeros_like(t)
                shift_y = -0.4 * np.abs(np.sin(t * 2 * np.pi))
            elif 'HELP' in label or 'AMBULANCE' in label or '911' in label:
                # Rapid upward or circular urgency motion
                shift_x = 0.2 * np.sin(t * 2 * np.pi)
                shift_y = -0.3 * t
            else:
                # General conversational gesture
                shift_x = 0.1 * np.cos(t * np.pi)
                shift_y = 0.15 * np.sin(t * np.pi)

            base_sample, _ = generate_static_samples([label], samples_per_class=1, language=language)
            base_vec = base_sample[0]

            for step in range(seq_len):
                frame_vec = base_vec.copy()
                # Modulate right hand position in feature coordinates
                frame_vec[63:126:3] += shift_x[step]   # x-channel
                frame_vec[64:126:3] += shift_y[step]   # y-channel
                # Add slight per-frame sensor noise
                frame_vec[:126] += np.random.normal(0, 0.008, 126)
                sequence[step] = frame_vec

            X.append(sequence)
            y.append(class_idx)

    return np.array(X, dtype=np.float32), np.array(y, dtype=np.int64)
