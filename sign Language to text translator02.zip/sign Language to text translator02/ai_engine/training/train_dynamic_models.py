"""
SignBridge AI - Dynamic Gesture Sequence Recognition Pipeline
Trains PyTorch Bidirectional LSTM (Bi-LSTM) networks with temporal attention.
Extracts spatiotemporal features from continuous 30-frame landmark sequences.
"""

import os
import sys

# Ensure root directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import json
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, precision_recall_fscore_support

from ai_engine.training.gesture_dataset_generator import generate_dynamic_sequences

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATASETS_DIR = os.path.join(BASE_DIR, "datasets")
SAVED_MODELS_DIR = os.path.join(BASE_DIR, "saved_models")
EVAL_DIR = os.path.join(BASE_DIR, "evaluation")


class TemporalAttention(nn.Module):
    """Computes attention weights over LSTM time steps."""
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.attn = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.Tanh(),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, lstm_out: torch.Tensor) -> torch.Tensor:
        # lstm_out shape: (batch, seq_len, hidden_dim)
        scores = self.attn(lstm_out)  # (batch, seq_len, 1)
        weights = torch.softmax(scores, dim=1)
        context = torch.sum(weights * lstm_out, dim=1)  # (batch, hidden_dim)
        return context


class SignBiLSTM(nn.Module):
    """
    Bidirectional LSTM with Temporal Attention for Dynamic Sign Recognition.
    """
    def __init__(self, input_dim: int = 150, hidden_dim: int = 128, num_layers: int = 2, num_classes: int = 10, dropout: float = 0.3):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        self.attention = TemporalAttention(hidden_dim * 2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.Dropout(dropout),
            nn.Linear(64, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, input_dim)
        out, _ = self.lstm(x)
        context = self.attention(out)
        logits = self.fc(context)
        return logits


def train_dynamic_for_language(language: str, epochs: int = 25, batch_size: int = 16) -> dict:
    print(f"\n==========================================")
    print(f"Training Dynamic Bi-LSTM for: {language}")
    print(f"==========================================")

    vocab_file = os.path.join(DATASETS_DIR, f"{language.lower()}_vocabulary.json")
    with open(vocab_file, "r") as f:
        vocab = json.load(f)

    classes = vocab["dynamic_classes"]
    num_classes = len(classes)
    print(f"Classes ({num_classes}): {classes}")

    # Generate sequence dataset
    X, y = generate_dynamic_sequences(classes, samples_per_class=90, seq_len=30, language=language)
    print(f"Generated sequence dataset X: {X.shape}, y: {y.shape}")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    train_ds = TensorDataset(torch.tensor(X_train, dtype=torch.float32), torch.tensor(y_train, dtype=torch.long))
    test_ds = TensorDataset(torch.tensor(X_test, dtype=torch.float32), torch.tensor(y_test, dtype=torch.long))

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Training on device: {device}")

    model = SignBiLSTM(input_dim=150, hidden_dim=128, num_layers=2, num_classes=num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)

    # Training loop
    model.train()
    history = []
    for epoch in range(epochs):
        total_loss = 0.0
        correct = 0
        total = 0
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            optimizer.zero_grad()
            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * batch_x.size(0)
            preds = torch.argmax(outputs, dim=1)
            correct += (preds == batch_y).sum().item()
            total += batch_y.size(0)

        epoch_loss = total_loss / total
        epoch_acc = correct / total
        if (epoch + 1) % 5 == 0 or epoch == epochs - 1:
            print(f"Epoch [{epoch+1}/{epochs}] Loss: {epoch_loss:.4f} | Train Acc: {epoch_acc*100:.2f}%")
        history.append({"epoch": epoch + 1, "loss": epoch_loss, "accuracy": epoch_acc})

    # Evaluation
    model.eval()
    all_preds = []
    all_targets = []
    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            batch_x = batch_x.to(device)
            outputs = model(batch_x)
            preds = torch.argmax(outputs, dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_targets.extend(batch_y.numpy())

    all_preds = np.array(all_preds)
    all_targets = np.array(all_targets)

    test_acc = accuracy_score(all_targets, all_preds)
    prec, rec, f1, _ = precision_recall_fscore_support(all_targets, all_preds, average="weighted")
    report = classification_report(all_targets, all_preds, target_names=classes, output_dict=True)

    print(f"Dynamic Test Accuracy: {test_acc * 100:.2f}% | Precision: {prec * 100:.2f}% | F1: {f1 * 100:.2f}%")

    # Serialize PyTorch Model
    model_dir = os.path.join(SAVED_MODELS_DIR, language.lower())
    os.makedirs(model_dir, exist_ok=True)
    model_save_path = os.path.join(model_dir, f"{language.lower()}_dynamic.pt")
    meta_save_path = os.path.join(model_dir, f"{language.lower()}_dynamic_classes.json")

    torch.save({
        "model_state_dict": model.state_dict(),
        "input_dim": 150,
        "hidden_dim": 128,
        "num_layers": 2,
        "num_classes": num_classes,
        "classes": classes,
        "language": language
    }, model_save_path)

    with open(meta_save_path, "w") as f:
        json.dump({
            "language": language,
            "classes": classes,
            "accuracy": float(test_acc),
            "seq_len": 30,
            "feature_dim": 150
        }, f, indent=2)

    print(f"Saved dynamic model to: {model_save_path}")

    return {
        "language": language,
        "classes_count": num_classes,
        "classes": classes,
        "test_samples": len(all_targets),
        "test_accuracy": float(test_acc),
        "weighted_precision": float(prec),
        "weighted_recall": float(rec),
        "weighted_f1": float(f1),
        "training_history": history,
        "classification_report": report
    }


def main():
    os.makedirs(EVAL_DIR, exist_ok=True)
    isl_dyn = train_dynamic_for_language("ISL", epochs=20)
    asl_dyn = train_dynamic_for_language("ASL", epochs=20)

    report = {
        "ISL_Dynamic": isl_dyn,
        "ASL_Dynamic": asl_dyn
    }

    report_path = os.path.join(EVAL_DIR, "dynamic_evaluation_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"\nDynamic evaluation report saved to: {report_path}")


if __name__ == "__main__":
    main()
