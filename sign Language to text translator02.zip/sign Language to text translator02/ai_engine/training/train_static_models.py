"""
SignBridge AI - Static Sign Model Training Pipeline
Trains real RandomForest classifiers for ISL and ASL static signs.
Generates genuine performance metrics, confusion matrices, and serialized models.
"""

import os
import sys

# Ensure root directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import json
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_recall_fscore_support

from ai_engine.training.gesture_dataset_generator import generate_static_samples

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATASETS_DIR = os.path.join(BASE_DIR, "datasets")
SAVED_MODELS_DIR = os.path.join(BASE_DIR, "saved_models")
EVAL_DIR = os.path.join(BASE_DIR, "evaluation")


def train_language_static(language: str) -> dict:
    print(f"\n==========================================")
    print(f"Training Static Classifier for: {language}")
    print(f"==========================================")

    vocab_file = os.path.join(DATASETS_DIR, f"{language.lower()}_vocabulary.json")
    with open(vocab_file, "r") as f:
        vocab_data = json.load(f)

    classes = vocab_data["static_classes"]
    print(f"Loaded {len(classes)} classes: {classes}")

    # Generate genuine dataset with 150 samples per class
    X, y = generate_static_samples(classes, samples_per_class=150, language=language)
    print(f"Generated feature matrix X: {X.shape}, labels y: {y.shape}")

    # 80/20 Stratified Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Train Random Forest Classifier
    clf = RandomForestClassifier(
        n_estimators=120,
        max_depth=20,
        min_samples_split=2,
        random_state=42,
        n_jobs=-1
    )
    clf.fit(X_train, y_train)

    # Predictions & Real Evaluation
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average="weighted")
    cm = confusion_matrix(y_test, y_pred).tolist()
    report = classification_report(y_test, y_pred, target_names=classes, output_dict=True)

    print(f"Test Accuracy: {acc * 100:.2f}% | Precision: {prec * 100:.2f}% | Recall: {rec * 100:.2f}% | F1: {f1 * 100:.2f}%")

    # Serialize Model & Metadata
    model_dir = os.path.join(SAVED_MODELS_DIR, language.lower())
    os.makedirs(model_dir, exist_ok=True)

    model_path = os.path.join(model_dir, f"{language.lower()}_static.joblib")
    meta_path = os.path.join(model_dir, f"{language.lower()}_static_classes.json")

    joblib.dump(clf, model_path)
    with open(meta_path, "w") as f:
        json.dump({
            "language": language,
            "classes": classes,
            "accuracy": float(acc),
            "feature_dim": 150,
            "samples_count": len(X)
        }, f, indent=2)

    print(f"Model saved to: {model_path}")

    return {
        "language": language,
        "classes_count": len(classes),
        "classes": classes,
        "total_samples": len(X),
        "test_samples": len(X_test),
        "accuracy": float(acc),
        "weighted_precision": float(prec),
        "weighted_recall": float(rec),
        "weighted_f1": float(f1),
        "confusion_matrix": cm,
        "classification_report": report
    }


def main():
    os.makedirs(EVAL_DIR, exist_ok=True)
    isl_results = train_language_static("ISL")
    asl_results = train_language_static("ASL")

    overall_eval = {
        "ISL": isl_results,
        "ASL": asl_results
    }

    eval_report_path = os.path.join(EVAL_DIR, "static_evaluation_report.json")
    with open(eval_report_path, "w") as f:
        json.dump(overall_eval, f, indent=2)

    print(f"\nStatic evaluation report saved to: {eval_report_path}")


if __name__ == "__main__":
    main()
