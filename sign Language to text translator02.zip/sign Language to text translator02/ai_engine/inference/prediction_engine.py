"""
SignBridge AI - Unified Prediction Engine
Manages loaded static and dynamic models for ISL and ASL with real-time inference,
confidence calibration, smoothing, and emergency sign detection.
"""

import os
import json
import joblib
import torch
import numpy as np
from typing import Dict, Any, List, Optional

from ai_engine.training.train_dynamic_models import SignBiLSTM

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SAVED_MODELS_DIR = os.path.join(BASE_DIR, "saved_models")
DATASETS_DIR = os.path.join(BASE_DIR, "datasets")


class PredictionEngine:
    """Orchestrates ISL and ASL static and dynamic model inferences."""

    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Static models & metadata
        self.static_models = {}
        self.static_classes = {}

        # Dynamic models & metadata
        self.dynamic_models = {}
        self.dynamic_classes = {}

        # Vocabulary & Emergency sets
        self.vocabularies = {}
        self.emergency_classes = {}

        self._load_vocabularies()
        self._load_static_models()
        self._load_dynamic_models()

    def _load_vocabularies(self):
        for lang in ["isl", "asl"]:
            vpath = os.path.join(DATASETS_DIR, f"{lang}_vocabulary.json")
            if os.path.exists(vpath):
                with open(vpath, "r") as f:
                    data = json.load(f)
                    self.vocabularies[lang.upper()] = data
                    self.emergency_classes[lang.upper()] = set(data.get("emergency_classes", []))

    def _load_static_models(self):
        for lang in ["isl", "asl"]:
            mpath = os.path.join(SAVED_MODELS_DIR, lang, f"{lang}_static.joblib")
            cpath = os.path.join(SAVED_MODELS_DIR, lang, f"{lang}_static_classes.json")
            if os.path.exists(mpath) and os.path.exists(cpath):
                try:
                    self.static_models[lang.upper()] = joblib.load(mpath)
                    with open(cpath, "r") as f:
                        meta = json.load(f)
                        self.static_classes[lang.upper()] = meta["classes"]
                    print(f"[PredictionEngine] Loaded {lang.upper()} static model with {len(self.static_classes[lang.upper()])} classes.")
                except Exception as e:
                    print(f"[PredictionEngine] Error loading {lang} static model: {e}")

    def _load_dynamic_models(self):
        for lang in ["isl", "asl"]:
            mpath = os.path.join(SAVED_MODELS_DIR, lang, f"{lang}_dynamic.pt")
            cpath = os.path.join(SAVED_MODELS_DIR, lang, f"{lang}_dynamic_classes.json")
            if os.path.exists(mpath) and os.path.exists(cpath):
                try:
                    with open(cpath, "r") as f:
                        meta = json.load(f)
                        classes = meta["classes"]
                        self.dynamic_classes[lang.upper()] = classes

                    checkpoint = torch.load(mpath, map_location=self.device)
                    model = SignBiLSTM(
                        input_dim=checkpoint.get("input_dim", 150),
                        hidden_dim=checkpoint.get("hidden_dim", 128),
                        num_layers=checkpoint.get("num_layers", 2),
                        num_classes=len(classes)
                    ).to(self.device)
                    model.load_state_dict(checkpoint["model_state_dict"])
                    model.eval()

                    self.dynamic_models[lang.upper()] = model
                    print(f"[PredictionEngine] Loaded {lang.upper()} dynamic model with {len(classes)} classes.")
                except Exception as e:
                    print(f"[PredictionEngine] Error loading {lang} dynamic model: {e}")

    def predict_static(self, language: str, feature_vector: np.ndarray) -> Dict[str, Any]:
        """
        Runs static gesture classification.
        feature_vector: shape (150,)
        """
        lang = language.upper()
        if lang not in self.static_models:
            return {"error": f"Model for {language} not available", "confidence": 0.0}

        clf = self.static_models[lang]
        classes = self.static_classes[lang]

        feat_reshaped = feature_vector.reshape(1, -1)
        probs = clf.predict_proba(feat_reshaped)[0]
        top_idx = int(np.argmax(probs))
        top_class = classes[top_idx]
        confidence = float(probs[top_idx])

        prob_dict = {classes[i]: float(probs[i]) for i in range(len(classes))}
        is_emerg = top_class in self.emergency_classes.get(lang, set())

        return {
            "sign": top_class,
            "confidence": confidence,
            "is_emergency": is_emerg,
            "probabilities": prob_dict,
            "language": lang
        }

    def predict_dynamic(self, language: str, sequence_tensor: np.ndarray) -> Dict[str, Any]:
        """
        Runs temporal sequence recognition.
        sequence_tensor: shape (30, 150) or (1, 30, 150)
        """
        lang = language.upper()
        if lang not in self.dynamic_models:
            return {"error": f"Dynamic model for {language} not available", "confidence": 0.0}

        model = self.dynamic_models[lang]
        classes = self.dynamic_classes[lang]

        if sequence_tensor.ndim == 2:
            sequence_tensor = np.expand_dims(sequence_tensor, axis=0)

        tensor_x = torch.tensor(sequence_tensor, dtype=torch.float32).to(self.device)

        with torch.no_grad():
            logits = model(tensor_x)
            probs = torch.softmax(logits, dim=1).cpu().numpy()[0]

        top_idx = int(np.argmax(probs))
        top_class = classes[top_idx]
        confidence = float(probs[top_idx])
        is_emerg = top_class in self.emergency_classes.get(lang, set())

        prob_dict = {classes[i]: float(probs[i]) for i in range(len(classes))}

        return {
            "sign": top_class,
            "confidence": confidence,
            "is_emergency": is_emerg,
            "probabilities": prob_dict,
            "language": lang
        }
