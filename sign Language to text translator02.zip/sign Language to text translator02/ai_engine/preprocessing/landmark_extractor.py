"""
SignBridge AI - Landmark Extractor
Computer Vision interface wrapping MediaPipe Tasks for Hands and Pose.
"""

import os
import cv2
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

from ai_engine.preprocessing.normalizer import (
    create_feature_vector,
    HAND_LANDMARKS_COUNT
)

HAND_MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "saved_models", "hand_landmarker.task"))
POSE_MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "saved_models", "pose_landmarker.task"))


# Hand landmark connections for drawing (pairs of indices)
HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),        # Thumb
    (0, 5), (5, 6), (6, 7), (7, 8),        # Index
    (5, 9), (9, 10), (10, 11), (11, 12),   # Middle
    (9, 13), (13, 14), (14, 15), (15, 16), # Ring
    (13, 17), (17, 18), (18, 19), (19, 20),# Pinky
    (0, 17)                                # Palm base
]


class LandmarkExtractor:
    """Extracts hand and body landmarks from single frames using MediaPipe Tasks."""

    def __init__(self, hand_model_path: str = HAND_MODEL_PATH, pose_model_path: str = POSE_MODEL_PATH):
        if not os.path.exists(hand_model_path):
            raise FileNotFoundError(f"Hand landmarker model not found at: {hand_model_path}")

        # Initialize Hand Landmarker
        hand_base_options = python.BaseOptions(model_asset_path=hand_model_path)
        hand_options = vision.HandLandmarkerOptions(
            base_options=hand_base_options,
            num_hands=2,
            min_hand_detection_confidence=0.5,
            min_hand_presence_confidence=0.5,
            min_tracking_confidence=0.5
        )
        self.hand_detector = vision.HandLandmarker.create_from_options(hand_options)

        # Initialize Pose Landmarker if available
        self.pose_detector = None
        if os.path.exists(pose_model_path):
            try:
                pose_base_options = python.BaseOptions(model_asset_path=pose_model_path)
                pose_options = vision.PoseLandmarkerOptions(
                    base_options=pose_base_options,
                    min_pose_detection_confidence=0.5,
                    min_pose_presence_confidence=0.5,
                    min_tracking_confidence=0.5
                )
                self.pose_detector = vision.PoseLandmarker.create_from_options(pose_options)
            except Exception as e:
                print(f"[LandmarkExtractor] Warning: Could not initialize pose detector: {e}")

    def process_frame(self, bgr_image: np.ndarray) -> Dict[str, Any]:
        """
        Processes a BGR image frame from OpenCV.
        Returns:
            {
                "hands_detected": int,
                "left_hand": List[Dict] or None,
                "right_hand": List[Dict] or None,
                "pose": List[Dict] or None,
                "feature_vector": np.ndarray (150,)
            }
        """
        h, w, _ = bgr_image.shape
        rgb_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_image)

        # Detect Hands
        hand_result = self.hand_detector.detect(mp_image)

        left_hand_lms = None
        right_hand_lms = None

        if hand_result.hand_landmarks:
            for idx, handedness_category in enumerate(hand_result.handedness):
                label = handedness_category[0].category_name  # "Left" or "Right"
                lms = [
                    {"x": lm.x, "y": lm.y, "z": lm.z}
                    for lm in hand_result.hand_landmarks[idx]
                ]
                # MediaPipe mirror convention: "Left" label corresponds to wearer's right in selfie view
                if label.lower() == "left":
                    left_hand_lms = lms
                else:
                    right_hand_lms = lms

            # If only one hand detected and not assigned, assign to right hand by default
            if left_hand_lms is None and right_hand_lms is None and len(hand_result.hand_landmarks) > 0:
                right_hand_lms = [
                    {"x": lm.x, "y": lm.y, "z": lm.z}
                    for lm in hand_result.hand_landmarks[0]
                ]

        # Detect Pose
        pose_lms = None
        if self.pose_detector:
            try:
                pose_result = self.pose_detector.detect(mp_image)
                if pose_result.pose_landmarks and len(pose_result.pose_landmarks) > 0:
                    pose_lms = [
                        {"x": lm.x, "y": lm.y, "z": lm.z, "visibility": getattr(lm, "visibility", 1.0)}
                        for lm in pose_result.pose_landmarks[0]
                    ]
            except Exception:
                pose_lms = None

        # Build feature vector
        feat_vec = create_feature_vector(left_hand_lms, right_hand_lms, pose_lms)

        hands_count = (1 if left_hand_lms else 0) + (1 if right_hand_lms else 0)

        return {
            "hands_detected": hands_count,
            "left_hand": left_hand_lms,
            "right_hand": right_hand_lms,
            "pose": pose_lms,
            "feature_vector": feat_vec
        }

    def draw_landmarks(self, bgr_image: np.ndarray, processed: Dict[str, Any]) -> np.ndarray:
        """Draws visual skeleton landmarks and connections over the frame."""
        annotated = bgr_image.copy()
        h, w, _ = annotated.shape

        for hand_lms, color in [(processed.get("left_hand"), (245, 117, 66)), (processed.get("right_hand"), (117, 245, 66))]:
            if not hand_lms:
                continue

            points = []
            for lm in hand_lms:
                cx, cy = int(lm["x"] * w), int(lm["y"] * h)
                points.append((cx, cy))
                cv2.circle(annotated, (cx, cy), 4, color, -1)
                cv2.circle(annotated, (cx, cy), 6, (255, 255, 255), 1)

            for p1_idx, p2_idx in HAND_CONNECTIONS:
                if p1_idx < len(points) and p2_idx < len(points):
                    cv2.line(annotated, points[p1_idx], points[p2_idx], color, 2)

        return annotated
