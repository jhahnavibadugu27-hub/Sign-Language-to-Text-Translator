"""
SignBridge AI - Landmark Normalization & Feature Engineering
Ensures translation, scale, and signer-distance invariance.
"""

import numpy as np
from typing import List, Optional, Tuple, Dict, Any

HAND_LANDMARKS_COUNT = 21
POSE_KEYPOINTS_COUNT = 7  # nose, left/right shoulder, left/right elbow, left/right wrist
FEATURE_VECTOR_DIM = 150   # 63 (left) + 63 (right) + 2 (hand flags) + 21 (pose) + 1 (pose flag)


def normalize_hand_landmarks(landmarks: List[Dict[str, float]]) -> np.ndarray:
    """
    Normalizes 21 landmarks of a single hand:
    1. Translates wrist (index 0) to origin (0, 0, 0).
    2. Scales by Euclidean distance between wrist (0) and middle finger MCP (9).
    Returns 63-dimensional flattened numpy array.
    """
    if not landmarks or len(landmarks) < HAND_LANDMARKS_COUNT:
        return np.zeros(HAND_LANDMARKS_COUNT * 3, dtype=np.float32)

    coords = np.array([[lm['x'], lm['y'], lm.get('z', 0.0)] for lm in landmarks], dtype=np.float32)

    # 1. Wrist Translation
    wrist = coords[0].copy()
    translated = coords - wrist

    # 2. Scale Normalization (Distance from wrist to middle finger MCP at index 9)
    middle_mcp = translated[9]
    scale_dist = np.linalg.norm(middle_mcp[:2])

    if scale_dist > 1e-4:
        normalized = translated / scale_dist
    else:
        normalized = translated

    return normalized.flatten().astype(np.float32)


def normalize_pose_landmarks(pose_landmarks: List[Dict[str, float]]) -> np.ndarray:
    """
    Normalizes selected upper-body pose landmarks:
    Indices corresponding to:
    0: nose, 11: left shoulder, 12: right shoulder,
    13: left elbow, 14: right elbow, 15: left wrist, 16: right wrist.
    Returns 21-dimensional numpy array centered relative to shoulder midpoint.
    """
    if not pose_landmarks or len(pose_landmarks) < 17:
        return np.zeros(POSE_KEYPOINTS_COUNT * 3, dtype=np.float32)

    selected_indices = [0, 11, 12, 13, 14, 15, 16]
    coords = []
    for idx in selected_indices:
        lm = pose_landmarks[idx]
        coords.append([lm['x'], lm['y'], lm.get('z', 0.0)])
    coords = np.array(coords, dtype=np.float32)

    # Midpoint of shoulders (indices 1 and 2 in selected list)
    shoulder_mid = (coords[1] + coords[2]) / 2.0
    translated = coords - shoulder_mid

    # Scale by shoulder width
    shoulder_width = np.linalg.norm(coords[1][:2] - coords[2][:2])
    if shoulder_width > 1e-4:
        normalized = translated / shoulder_width
    else:
        normalized = translated

    return normalized.flatten().astype(np.float32)


def create_feature_vector(
    left_hand: Optional[List[Dict[str, float]]] = None,
    right_hand: Optional[List[Dict[str, float]]] = None,
    pose: Optional[List[Dict[str, float]]] = None
) -> np.ndarray:
    """
    Assembles complete 150-dimensional multimodal feature vector:
    - 63 floats: Normalized Left Hand (zeros if absent)
    - 63 floats: Normalized Right Hand (zeros if absent)
    - 2 floats: Presence indicator flags [has_left, has_right]
    - 21 floats: Normalized Upper Pose Keypoints (zeros if absent)
    - 1 float: Pose presence flag [has_pose]
    Total = 63 + 63 + 2 + 21 + 1 = 150 features.
    """
    has_left = 1.0 if (left_hand and len(left_hand) == HAND_LANDMARKS_COUNT) else 0.0
    has_right = 1.0 if (right_hand and len(right_hand) == HAND_LANDMARKS_COUNT) else 0.0
    has_pose = 1.0 if (pose and len(pose) >= 17) else 0.0

    left_feat = normalize_hand_landmarks(left_hand) if has_left else np.zeros(63, dtype=np.float32)
    right_feat = normalize_hand_landmarks(right_hand) if has_right else np.zeros(63, dtype=np.float32)
    pose_feat = normalize_pose_landmarks(pose) if has_pose else np.zeros(21, dtype=np.float32)

    flags = np.array([has_left, has_right, has_pose], dtype=np.float32)

    vector = np.concatenate([left_feat, right_feat, flags[:2], pose_feat, flags[2:]])
    return vector.astype(np.float32)
