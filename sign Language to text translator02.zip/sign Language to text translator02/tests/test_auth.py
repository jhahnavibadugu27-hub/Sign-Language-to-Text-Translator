"""
SignBridge AI - Unit Tests for Authentication & Security
"""

import pytest
from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.core.security import hash_password, verify_password, create_access_token, decode_access_token

client = TestClient(app)


def test_password_hashing():
    pwd = "SecretPassword123!"
    hashed = hash_password(pwd)
    assert hashed != pwd
    assert verify_password(pwd, hashed) is True
    assert verify_password("WrongPassword", hashed) is False


def test_jwt_token_lifecycle():
    payload = {"sub": "test@signbridge.ai", "user_id": "user-42"}
    token = create_access_token(payload)
    assert isinstance(token, str)
    decoded = decode_access_token(token)
    assert decoded["sub"] == "test@signbridge.ai"
    assert decoded["user_id"] == "user-42"


def test_register_and_login_flow():
    email = "evaluator_test@signbridge.ai"
    # Register
    reg_resp = client.post("/api/auth/register", json={
        "full_name": "Test Evaluator",
        "email": email,
        "password": "Password123!",
        "preferred_language": "ISL"
    })
    assert reg_resp.status_code in [200, 400]  # 400 if already created in earlier test run

    # Login
    login_resp = client.post("/api/auth/login", json={
        "email": email,
        "password": "Password123!"
    })
    assert login_resp.status_code == 200
    data = login_resp.json()
    assert "access_token" in data
    assert data["user"]["email"] == email
