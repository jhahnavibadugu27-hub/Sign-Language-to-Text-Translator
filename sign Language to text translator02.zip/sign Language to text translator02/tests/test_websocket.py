"""
SignBridge AI - Unit Tests for WebSocket Live Translation
"""

import json
from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def test_websocket_ping_pong():
    with client.websocket_connect("/ws/live-translate") as ws:
        ws.send_text(json.dumps({"type": "ping"}))
        response = ws.receive_text()
        data = json.loads(response)
        assert data["type"] == "pong"


def test_websocket_config_and_clear():
    with client.websocket_connect("/ws/live-translate") as ws:
        # Config switch to ASL
        ws.send_text(json.dumps({"type": "config", "language": "ASL"}))
        resp1 = json.loads(ws.receive_text())
        assert resp1["type"] == "configured"
        assert resp1["language"] == "ASL"

        # Clear sentence buffer
        ws.send_text(json.dumps({"type": "clear"}))
        resp2 = json.loads(ws.receive_text())
        assert resp2["type"] == "cleared"
        assert resp2["tokens"] == []
