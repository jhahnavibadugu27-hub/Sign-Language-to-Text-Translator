"""
SignBridge AI - Unit Tests for Translation & Analytics Endpoints
"""

import os
import io
import cv2
import numpy as np
import pytest
from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)


def test_supported_languages():
    resp = client.get("/api/translation/languages")
    assert resp.status_code == 200
    data = resp.json()
    assert "languages" in data
    codes = [l["code"] for l in data["languages"]]
    assert "ISL" in codes
    assert "ASL" in codes


def test_emergency_alert_endpoint():
    resp = client.post("/api/translation/emergency", json={
        "message": "I need medical assistance immediately",
        "language": "ISL",
        "manual_override": True
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["success"] is True
    assert "Emergency Alert!" in data["spoken_phrase"]


def test_dashboard_analytics():
    resp = client.get("/api/dashboard/analytics")
    assert resp.status_code == 200
    data = resp.json()
    assert "total_translations" in data
    assert "model_benchmarks" in data
    assert "modalities" in data


def test_history_endpoint():
    resp = client.get("/api/history?page=1&limit=5")
    assert resp.status_code == 200
    data = resp.json()
    assert "items" in data
    assert "total" in data


def test_video_upload_and_job_lifecycle(tmp_path):
    # Generate a small 1-second synthetic video using OpenCV
    video_file = tmp_path / "test_sign.mp4"
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(str(video_file), fourcc, 15.0, (320, 240))
    for _ in range(15):
        frame = np.zeros((240, 320, 3), dtype=np.uint8)
        out.write(frame)
    out.release()

    with open(video_file, "rb") as f:
        resp = client.post(
            "/api/translation/video",
            files={"file": ("test_sign.mp4", f, "video/mp4")},
            data={"language": "ISL"}
        )

    assert resp.status_code == 200
    data = resp.json()
    assert "job_id" in data
    job_id = data["job_id"]

    # Poll status
    status_resp = client.get(f"/api/jobs/{job_id}")
    assert status_resp.status_code == 200
    status_data = status_resp.json()
    assert status_data["job_id"] == job_id
