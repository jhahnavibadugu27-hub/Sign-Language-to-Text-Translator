"""
SignBridge AI - Unit Tests for Feature Normalization & Prediction Engine
"""

import numpy as np
import pytest
from ai_engine.preprocessing.normalizer import (
    normalize_hand_landmarks,
    create_feature_vector,
    FEATURE_VECTOR_DIM
)
from ai_engine.inference.prediction_engine import PredictionEngine


def test_feature_vector_dimension():
    # Empty inputs should yield zeros of exactly FEATURE_VECTOR_DIM (150)
    feat = create_feature_vector(None, None, None)
    assert feat.shape == (FEATURE_VECTOR_DIM,)
    assert np.all(feat == 0.0)


def test_hand_normalization_invariance():
    # Synthetic hand at origin
    hand_a = [{"x": float(i)*0.01, "y": float(i)*0.02, "z": 0.0} for i in range(21)]
    # Translated hand
    hand_b = [{"x": float(i)*0.01 + 0.5, "y": float(i)*0.02 + 0.3, "z": 0.0} for i in range(21)]

    norm_a = normalize_hand_landmarks(hand_a)
    norm_b = normalize_hand_landmarks(hand_b)

    # Wrist centering should make both identical
    np.testing.assert_allclose(norm_a, norm_b, atol=1e-5)


def test_prediction_engine_static():
    engine = PredictionEngine()
    dummy_feat = np.random.normal(0, 0.1, 150).astype(np.float32)

    # Test ISL static
    res_isl = engine.predict_static("ISL", dummy_feat)
    assert "sign" in res_isl
    assert "confidence" in res_isl
    assert 0.0 <= res_isl["confidence"] <= 1.0

    # Test ASL static
    res_asl = engine.predict_static("ASL", dummy_feat)
    assert "sign" in res_asl
    assert "confidence" in res_asl


def test_prediction_engine_dynamic():
    engine = PredictionEngine()
    dummy_seq = np.random.normal(0, 0.1, (30, 150)).astype(np.float32)

    # Test ISL dynamic
    res_isl = engine.predict_dynamic("ISL", dummy_seq)
    assert "sign" in res_isl
    assert "confidence" in res_isl

    # Test ASL dynamic
    res_asl = engine.predict_dynamic("ASL", dummy_seq)
    assert "sign" in res_asl
    assert "confidence" in res_asl
